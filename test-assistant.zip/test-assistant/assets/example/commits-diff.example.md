# 代码变更 Diff 示例

> 本文件展示代码变更工具（如 Serena 代码工具）输出的典型 diff 报告结构，供 ingest 阶段参考解析格式。

---

以下是 feat/tn_10.8.56_appscope_jsapicallback 分支相对于 master 的代码变更：

---
## 📊 变更概览

| 统计项 | 数量 |
|--------|------|
| 变更文件数 | 17 个 |
| 涉及平台 | 鸿蒙 + iOS + Core (C++) |
| 主要改动 | JSAPI callback 生命周期管理 |

---
## 📁 变更文件列表

### Core (C++ 核心层)

| 文件 | 改动说明 |
|------|----------|
| Core/B2HBaseEvaluator.cpp | 核心改动: appDestroy/pagePause 事件自动触发 callback 回调 |
| ohosProject/src/main/cpp/core/B2HPlatformUtil.cpp | 同步 JSAPI 调用的引用计数管理修复 |
| ohosProject/src/main/cpp/core/enhanced_sync_jsapi/callback_manager.cpp | 新增 hasCallback() 方法检查回调是否存在 |
| ohosProject/src/main/cpp/core/enhanced_sync_jsapi/callback_manager.h | 接口声明 |
| ohosProject/src/main/cpp/core/enhanced_sync_jsapi/enhanced_sync_invoker.cpp | 回调调用前的存在性检查 |
| ohosProject/src/main/cpp/include/CubePlatform/B2HCubePlatformUtils.h | 新增 DestroyScene() 接口 |
| ohosProject/src/main/cpp/napi/native_engine_export.cpp | 关键改动: App 事件通知支持回调、Page 销毁通知、Scene 销毁 |
| ohosProject/src/main/cpp/types/libbundle2h_core/index.d.ts | notifyAppEvent 接口增加 callbackId 参数 |

### 鸿蒙端

| 文件 | 改动说明 |
|------|----------|
| instance.ets (engine-manager) | 核心改动: callback 从 Page 级别提升到 App 级别，新增 onAppEventNotified/onPageDestroyed |
| manager.ets (engine-manager) | 注册全局回调 onPageDestroyed/onAppEventNotified |
| instance.ets (engine impl) | App 销毁延迟 2 秒执行，新增 onPageDestroyed |
| instance.ets (page) | 核心改动: Page 级别 callback 管理，支持 onDestroyed 清理 |
| manager.ets (page) | Page 销毁时清理 callback 并从 map 移除 |
| shared-engine.ets | 接口定义更新，移除 IPageCreatedResponse |
| native-proxy.ets | 新增枚举 onPageDestroyed/onAppEventNotified |

### iOS 端

| 文件 | 改动说明 |
|------|----------|
| B2HAppDelegateImpl.m | 标记 APP_CREATE_TASK_CALLED 状态 |

---
## 🔑 关键代码变更

### 1. Callback 从 Page 级别提升到 App 级别

```typescript
// 之前: callback 绑定在 Page 级别
private pageEventCallbackMap = new Map<string, Function>();

// 之后: callback 绑定在 App 级别
private appEventCallbackMap = new Map<string, Function>();
```

### 2. appDestroy/pagePause 自动触发 callback (C++)

```cpp
// Core/B2HBaseEvaluator.cpp
#if defined(OS_OHOS)
    if ((name == "appDestroy" || name == "pagePause") && !id.empty()) {
        PAGE_JS_FUNCTION_CALLBACK callback = getCallback(id);
        if (callback) {
            callback(nullptr);
            removeCallback(id);
        }
    }
#endif
```

### 3. Page 销毁时清理资源

```typescript
// page/manager.ets
public onPageDestroyed(sceneId: string) {
    const pageEngine = this.pageMap.get(sceneId);
    if (!pageEngine) {
      return;
    }
    pageEngine.onDestroyed();
    this.pageMap.delete(sceneId);  // 从 map 移除
}
```

### 4. App 销毁延迟执行

```typescript
// engine impl
public destroy(): void {
    if (this.enableB2HEngine) {
      // 给 view 销毁一个时间
      setTimeout(() => {
        this.engine.destroy();
        B2HAppEngineManager.getInstance().removeEngineById(this.getId());
      }, 2000);
    }
}
```

---
## 🎯 变更目的

这些改动实现了将 JSAPI callback 生命周期从 Page 级别提升到 App 级别，解决了"页面退出后 callback 不回调"的问题。核心机制：

1. App 级别存储 callback → 页面销毁不影响 callback
2. appDestroy/pagePause 自动触发 → 确保回调被执行
3. Page 销毁通知 → 清理 Page 相关资源
4. 延迟销毁 App → 给回调执行留出时间
