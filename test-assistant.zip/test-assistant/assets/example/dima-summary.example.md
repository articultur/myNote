# Dima 需求总结示例

> 本文件展示通过 Dima MCP 拉取需求详情后的结构化总结格式，供 ingest/analyze 阶段参考。

---

可以读取。让我通过 Dima MCP 获取该需求的详情。

`arkai-dimamcpserver - queryWorkItemDetail (MCP)(workItemId: "2026022800114357381")`

---
## 📋 需求详情

| 字段 | 内容 |
|------|------|
| 需求 ID | 2026022800114357381 |
| 需求名称 | 【P1】【三端】同一 appId 切流场景下增加最低版本 bundle 依赖能力 |
| 优先级 | 高 |
| 状态 | 待处理 |
| 迭代 | 10.8.56 |
| 创建人 | 亦池 |
| 处理人 | 唐诺 |
| 空间 | 支付宝JS跨平台：小程序原生应用（原 Bundle 2.5） |

---
## 📝 需求内容

### 需求背景

在使用同一 appId 进行切流的场景下，需要增加最低版本 bundle 依赖能力。

### 需求描述

支持在切流时配置最低版本 bundle 依赖，确保：
- 切流时能够校验 bundle 版本依赖关系
- 不满足最低版本要求的场景能够有相应的降级或提示策略

### 期望效果

1. 支持配置最低版本 bundle 依赖
2. 切流时自动校验版本依赖
3. 版本不满足时有明确的处理机制

---
## 🎯 需求核心目的

这个需求的核心是：在“同一 appId 切流”场景下，增加对 bundle 最低版本的校验能力。

### 业务场景

当小程序通过 MiniToBundle2hSameAppId 机制进行切流时（即小程序切换到 Bundle2H 运行），需要确保：
- 客户端/Bundle 版本满足最低要求
- 不满足时有降级策略（不走切流，保持原有小程序运行）

### 与现有配置的关系

根据项目文档，现有的同一 appId 切流配置为：

```json
{
  "switch": true,
  "minVersion": "1.0.2345",
  "matches": [
    { "key": "scene", "value": "home" }
  ]
}
```

本需求可能需要扩展此配置，增加 bundle 版本依赖字段，例如：

```json
{
  "switch": true,
  "minVersion": "1.0.2345",
  "minBundleVersion": "10.8.56",
  "matches": []
}
```

---
## 🔗 相关链接

- Dima 链接: https://project.alipay.com/workItem?workItemId=2026022800114357381
