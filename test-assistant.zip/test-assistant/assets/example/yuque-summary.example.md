# 语雀文档总结示例

> 本文件展示通过语雀 MCP 拉取文档详情后的结构化总结格式，供 ingest/analyze 阶段参考。

---

`faas-skylarkmcpserver-skylarkmcpserver - skylark_user_doc_detail (MCP)(namespace: "pengzhan.wpz/kb", slug: "xu58gbqohr1hqet6")`

---
## 📋 文档详情

| 字段 | 内容 |
|------|------|
| 标题 | 【系分】bundle2h 唤端上报保证T1/T2时序 |
| 作者 | 格武 (pengzhan.wpz) |
| 更新时间 | 2025-12-05 |
| 文档链接 | https://yuque.antfin.com/pengzhan.wpz/kb/xu58gbqohr1hqet6 |

---
## 📝 需求内容

### 背景

在小程序体系中：
- T1: 页面出现，用户可见
- T2: 页面加载完成（目前定义为 pageOpen）

问题：
- 在 Bundle 2.5 中，T1 和 T2 的定义一样
- 但由于 Bundle 2.5 中页面和 JS 运行相对独立，无法保证 T1 和 T2 的时序
- 即 T1 不一定在 T2 之前到达
- 但唤端链路对于上报的定义，强依赖 T1 < T2
- 因此需要在容器侧做一些逻辑，强保障时序

### 方案

情况 1: T1 → T2（正常流程）

T1 → 上报T1 → T2 → 上报T2

情况 2: T2 → T1（乱序情况）

T2 → 暂存T2 → T1 → 上报 T1 → 修改T2.time = Max(T2, T1) → 上报T2

核心逻辑：
- 如果 T2 先于 T1 到达，先暂存 T2
- 等待 T1 到达后，先上报 T1
- 然后修改 T2 的时间为 Max(T2.time, T1.time)
- 最后上报 T2

---
## 关键日志

日志关键字：TaskRecorderBizObserver

iOS 中 phase 字段值：
- T1 枚举值: 3
- T2 枚举值: 4

2025-12-02 14:56:43.356 TaskRecorderBizObserver callResult:

```json
{"phase":"3","time":"1764658603354"}
{"phase":"4","time":"1764658603354"}
```

---
## 配置开关

```json
{
  "value": "yes",
  "key": "b2h_ensure_t2_after_t1"
}
```

---
## 🎯 需求核心目的

这个需求的核心是：在 Bundle 2.5 容器侧增加时序保障机制，确保唤端上报的 T1（页面可见）一定在 T2（页面加载完成）之前上报。

### 为什么需要这个

| 问题 | 影响 |
|------|------|
| T2 先于 T1 到达 | 唤端链路的数据统计不准确 |
| 时序错乱 | 无法正确判断页面加载性能 |

### 解决方案

通过暂存 + 时间修正机制，强制保证 T1 先上报，T2 后上报，即使实际到达顺序相反。
