---
name: test-assistant
description: Use when 需要基于需求生成测试分析文档、查询需求关联的多源信息（提交/设计/评审）、核对代码与文档一致性、或执行测试团队运维诊断。
metadata:
  user-invocable: true
  argument-hint: "init | ingest <REQ-ID or Dima-URL> | refetch <REQ-ID> | analyze <REQ-ID>"
---

# Test Assistant

专为测试团队打造的需求联动助手。核心功能是基于需求 ID，聚合代码提交、设计文档、评审记录等多源信息，生成结构化的测试分析文档。

## When to Use

- 针对需求生成测试分析文档（核心功能）
- 查看需求关联的提交记录、设计文档、评审记录
- 核对代码实现与文档是否一致
- 执行运维诊断（配置、MCP、Serena 健康）

**触发示例**：test assistant init / ingest REQ-2026-001 / refetch REQ-2026-001 / analyze REQ-2026-001 / 启动测试助手 / 录入需求 REQ-2026-001 / 生成测试分析 REQ-2026-001

## Sub-commands

| 指令 | 说明 |
|------|------|
| `init` | Bootstrap 工作区，检查配置、MCP、Serena 索引 |
| `ingest <REQ-ID>` | 录入需求关联数据（提交、设计文档、评审记录），写入本地文件并同步 Serena 摘要 |
| `refetch <REQ-ID>` | 强制执行 ingest 第 7 步：重新拉取并分析多源数据（忽略已有拉取缓存） |
| `analyze <REQ-ID>` | 聚合多源数据，生成结构化测试分析文档 |

## Procedure

**来源与结论统一强制规则（全流程生效）**：资料查询必须优先使用 `.test-assistant/config.json` 中已配置来源（`knowledgeBases`、`repositories`、`yuqueNamespaces`、`testKnowledgeBases`、`testReportYuqueUrls`、`testCodeRepos`）。所有输出结论必须可追溯到这些配置来源获取的证据；若配置来源缺失、不可用或证据不足，则不得给出确定性结论，必须明确告知缺失项并要求使用者补充对应资源（知识库/语雀/代码仓库/评审链接）。

**结论验证规则（全流程生效，包括 ad-hoc 查询）**：

> **⚠️ 与 Credibility Levels 的关系**：本规则中的"验证优先级"与 [Credibility Levels](#credibility-levels) 一致，Level 1 优先于 Level 2，以此类推。输出结论时必须标注可信度层级。

1. **适用范围**：以下规则适用于 **所有用户交互场景**，包括标准流程（init/ingest/analyze）和非标准流程的临时查询（"这个修改会影响其他模块吗"、"三端差异是什么"等）
2. **验证优先级（与 Credibility Levels 一致）**：
   - Level 1（最高）：代码实现验证 → 查询具体代码文件/方法实现，确认行为
   - Level 2：文档/评审记录 → 查询设计文档、评审记录确认设计意图
   - Level 3：仓库概览/知识库 → 使用概览或知识库检索补充上下文
   - Level 4（最低）：通用知识 → 仅在无法获取上述来源时使用，并标注"来源：通用知识"
3. **结论检查点（输出前必须确认）**：给出任何结论前必须确认：
   - 结论是否有代码/文档证据支撑？（无证据则不得给出确定性结论）
   - 是否区分了"事实"和"假设"？（假设性结论必须标注"待查证"）
   - 不确定的部分是否标注为"待查证"？
   - **输出检查结果**：在结论输出前，必须在对话中明确输出"✅ 检查通过"或"⚠️ 待查证：xxx"
4. **禁止假设性结论（红线行为）**：以下行为**绝对禁止**，违反则结论无效：
   - 涉及"可能/或许/应该/大概/不确定"等不确定表述但未验证
   - 给出技术结论但无法追溯到具体代码位置
   - 在验证完成前给出确定性结论
5. **待查证格式**：无法确认的结论必须使用以下格式标注：
   ```
   ## 待查证清单

   | # | 问题 | 需要验证的内容 | 验证方式 |
   |---|------|----------------|----------|
   | 1 | [具体问题] | [需验证的内容] | [验证方式] |

   **验证完成前不输出确定性结论**
   ```
6. **用户追问场景**：当用户要求"确认"、"验证"、"查证"结论时，**必须执行验证**，不得以"已经确认过"或"根据之前结论"为由跳过验证
7. **验证失败处理**：
   - 若验证失败（如代码不可访问、文档缺失），结论降级为"待确认"，并标注原因
   - 不得因验证失败而跳过结论输出，应明确告知用户"无法确认，需补充资源"
8. **触发标准流程**：若查询内容涉及需求分析、测试建议生成，应引导用户进入 analyze 流程

**存储职责说明（全流程生效）**：`.test-assistant/requirements/<REQ-ID>/meta.json` 用于保存需求元信息与录入链接；`docs/requirements/<REQ-ID>/sources/` 与 `analysis-summary.md` 用于保存按来源拆分的详细分析结果与汇总结论；`docs/requirements/<REQ-ID>/test-analysis.md` 用于保存最终输出的测试分析文档 Markdown 正文。最终测试分析文档必须以 `docs/requirements/<REQ-ID>/sources/*.md` 与 `docs/requirements/<REQ-ID>/analysis-summary.md` 中已落盘的分析资料为主要依据，不得脱离这些本地资料单独生成结论。

**Superpowers 强制触发规则（全流程生效）**：当满足触发条件时，必须先执行对应 superpowers 技能，再继续当前步骤。

| 技能 | 用途 | 触发时机 |
|------|------|----------|
| `superpowers:brainstorming` | 创意工作前的头脑风暴 | 创建功能、构建组件、添加功能、修改行为之前 |
| `superpowers:systematic-debugging` | 系统化调试 | 遇到 Bug、测试失败、异常行为时，在提出修复方案之前 |
| `superpowers:test-driven-development` | 测试驱动开发 | 实现任何功能或修复 Bug 时，在编写实现代码之前 |
| `superpowers:writing-plans` | 实现计划编写 | 有规格说明或需求的多步骤任务，在动代码之前 |
| `superpowers:executing-plans` | 执行实现计划 | 有已写好的实现计划需要在独立会话中执行时 |
| `superpowers:verification-before-completion` | 完成前验证 | 声称工作完成、修复、通过之前，在提交或创建 PR 之前 |
| `superpowers:finishing-a-development-branch` | 开发分支收尾 | 实现完成、测试通过后，决定如何集成工作时 |
| `superpowers:using-git-worktrees` | Git Worktree 使用 | 开始需要与当前工作区隔离的功能开发，或执行实现计划之前 |
| `superpowers:requesting-code-review` | 请求代码审查 | 完成任务、实现主要功能、合并前验证工作时 |
| `superpowers:receiving-code-review` | 接收代码审查 | 收到代码审查反馈，在实施建议之前 |
| `superpowers:dispatching-parallel-agents` | 并行 Agent 调度 | 面临 2+ 个独立任务，且无共享状态或顺序依赖时 |
| `superpowers:subagent-driven-development` | 子 Agent 驱动开发 | 在当前会话中执行具有独立任务的实现计划时 |
| `superpowers:writing-skills` | 编写技能 | 创建新技能、编辑现有技能、部署前验证技能时 |

### init

> init 流程的价值在于确保工作区状态一致——没有 CLAUDE.md 会导致后续所有会话丢失项目约定，配置占位值会导致 analyze 时无法检索任何真实数据源，MCP 缺失会导致 Dima/语雀调用静默失败。**六步必须按顺序执行，不得跳过或调换顺序。**

1. **检查 `CLAUDE.md`（最容易被跳过，务必执行）**：读取项目根目录是否存在 `CLAUDE.md`；缺失则将 `assets/CLAUDE.md.example` 复制到项目根目录的 `CLAUDE.md`，并告知用户已复制
2. 执行 [validate-config.sh](./scripts/validate-config.sh)，报告校验结果：
   - 脚本会检测字段是否仍为精确匹配的占位字符串（如 `"kb-xxxxx"` 或 `"https://code.alipay.com/group/repo.git"`）
   - **注意**：若数组内包含多个不同的占位值（如 `["kb-xxxxx", "kb-yyyyy"]`），脚本不会触发警告——需要在步骤 5 人工检查
   - 配置无效则阻断并返回字段级错误
3. 执行 [check-mcps.sh](./scripts/check-mcps.sh)，报告可用性结果：缺失必需 MCP 则进入降级模式并返回安装命令
4. 执行 [rag-status.sh](./scripts/rag-status.sh)，报告 Serena 索引新鲜度和概览完整性：
   - rag-status.sh exit 1 = 概览文件缺失（配置的来源无对应概览）→ 强制进入步骤 6
   - rag-status.sh exit 2 = 概览过期或索引不完整 → 建议进入步骤 6
   - rag-status.sh exit 0 = 状态健康
5. 检查 `.test-assistant/config.json` 中各字段是否仍为占位值或为空（包括多值数组中的每一项），依次引导用户填写并写入 `config.json`：
   - **开发侧配置**（用于 analyze 时检索代码/文档）：
     - `knowledgeBases`：开发知识库 ID 列表（示例：`["kb-xxxxx"]`）
     - `repositories`：开发代码仓库地址列表（示例：`["https://code.alipay.com/group/repo.git"]`）
     - `yuqueNamespaces`：开发文档语雀 Namespace 列表（示例：`["team/space"]`）
   - **测试侧配置**：
     - `testKnowledgeBases`：测试知识库 ID 列表（格式同 `knowledgeBases`，示例：`["kb-xxxxx"]`）
     - `testReportYuqueUrls`：测试报告语雀空间地址列表（用于上传测试分析文档，可多个）
     - `testCodeRepos`：测试代码仓库地址列表（可多个）
   - 以上各项均为选填，用户可逐项跳过；至少有一项来源配置（`knowledgeBases` / `repositories` / `yuqueNamespaces` / `testKnowledgeBases` / `testReportYuqueUrls` / `testCodeRepos`）才可正常使用 analyze 功能
6. **生成开发/测试来源概览（强制）**：按 `.test-assistant/config.json` 中已配置来源拉取并生成概览，写入 `.test-assistant/overviews/`：
   - 触发条件：只有当 `.test-assistant/config.json` 中存在至少一个来源配置（`knowledgeBases`/`repositories`/`yuqueNamespaces`/`testKnowledgeBases`/`testCodeRepos`/`testReportYuqueUrls`）时，才执行本步骤
   - 开发侧：`knowledgeBases`、`repositories`、`yuqueNamespaces`
   - 测试侧：`testKnowledgeBases`、`testCodeRepos`、`testReportYuqueUrls`
   - 产出要求：每个已配置来源至少生成 1 份对应概览；若来源为空或不可访问，记录失败原因并在 init 输出中提示
   - 完整性验证：执行后通过 [rag-status.sh](./scripts/rag-status.sh) 确认配置的每个来源都有对应概览文件
   - 文件命名规范（强制）：`<domain>__<sourceType>__<sourceId>.md`
     - `domain`：`dev` 或 `test`
     - `sourceType`：`kb` / `repo` / `yuque`
     - `sourceId`：对原始来源标识做可读归一化（小写、非字母数字转 `-`、去除首尾 `-`）；若归一化后重复，追加短哈希后缀避免覆盖
     - 示例：`dev__kb__kb-foo.md`、`dev__repo__code-alipay-com-group-a-git.md`、`test__yuque__yuque-antfin-com-team-space.md`
   - 状态更新：成功后更新 `.test-assistant/rag-status.json`（至少包含 `repo-overview`、`design-docs`）与 `.test-assistant/last-update.json` 的对应时间戳

### ingest <REQ-ID | Dima-URL>

> ingest 的核心职责是：将需求来源信息落盘到规定目录结构，保证后续 analyze 可以从本地文件中稳定读取数据，而不依赖临时网络调用。路径必须严格遵循，否则 analyze 找不到数据源。

1. 识别输入类型：
   - 未提供 → 询问需求 ID 或 Dima 链接
   - `project.alipay.com` URL → 提取 `openWorkItemId` 作为 REQ-ID，自动标记 Dima 来源
   - 纯 ID → 直接使用
   - 用户明确表示没有 REQ-ID → 用 `openWorkItemId` 作为 REQ-ID；若也没有则询问需求名称，按 `REQ-<YYYYMMDD>-<序号>` 自动生成 REQ-ID 并告知用户
2. 检查来源索引文件是否存在（路径必须为 **`.test-assistant/requirements/<REQ-ID>/meta.json`**，不是其他路径）：
   - 不存在 → 进入**引导录入**（见下）
   - 已存在 → 询问是否覆盖更新
3. **引导录入**（逐步提问，用户可跳过非必填项）：
   - 需求名称（必填；若来自 Dima URL 则自动拉取，无需手填）
   - Dima 链接（选填；若入参已是 URL 则自动填入并拉取详情）
   - 语雀文档链接（选填，填写后自动读取正文）
   - 代码提交 ID 列表（选填，可多个，逗号分隔）
   - 设计文档 / 评审记录链接（选填）
4. 将引导录入数据写入来源索引文件，路径必须为 **`.test-assistant/requirements/<REQ-ID>/meta.json`**（如需了解字段格式，参考 [assets/example/](./assets/example/) 中的模板）：
   - `requirementId` = REQ-ID
   - `requirementName` = 引导录入[1]
   - `dimaId` = 从 Dima URL 提取或引导录入[2]
   - `dimaUrl` = 原始 Dima URL（若为 URL 入参则原样保存）
   - `yuqueUrl` = 引导录入[3]
   - `source` = `"dima-url"` / `"manual"`（按入参类型）
   - `hasCommits` / `hasDesignDoc` / `hasReviewRecords` = 按实际填写项设为 `true`
5. 更新 `.test-assistant/rag-status.json` 的 `indexedSources`
6. **自动触发数据拉取与分析**（无需用户确认）：

   > **💡 需求类型提示（可选）**：在分析开始前，可快速识别需求类型，决定本次需要重点收集什么维度：
   > - **Feature-Anchor 扫描**：从 Dima 详情/语雀正文摘要中识别功能关键词（架构/超时/厂商/协议/并发/异常/日志监控）
   > - **Change-Anchor 扫描**：从提交记录中识别变更类型（新增接口/逻辑调整/资源清理/状态管理）
   > - 根据识别结果，在下方分析时自动加强对应维度的深度

   - 若有 Dima 链接 → 调用 Dima MCP 拉取需求详情（输出格式参考 [dima-summary.example.md](./assets/example/dima-summary.example.md)，通常包含：需求详情表、需求背景/描述/期望效果、核心目的、相关链接），直接分析：
     - 需求范围与边界（做什么/不做什么）
     - 验收标准与可测试条件（成功标准、失败/降级策略）
     - 业务约束与技术约束（版本、平台、配置项、依赖关系）
     - 与现有配置/机制的差异点（新增字段、行为变化、兼容性影响）
   - 若有语雀链接 → 读取语雀正文（输出格式参考 [yuque-summary.example.md](./assets/example/yuque-summary.example.md)...读取正文后，**必须提取文档中所有图片 URL（支持 Markdown/HTML img/srcset/picture/CSS background/data-uri 等格式），逐一执行以下步骤**：
> 1. 用扩大后的正则提取文档中所有图片 URL，记录到 `meta.json.detectedImageUrls`
> 2. 创建 `docs/requirements/<REQ-ID>/sources/images/` 目录
> 3. 调用 `scripts/download-images.sh` 下载每张图片到本地（失败重试3次，仍失败则标注 `[图片解析失败]`）
> 4. 调用 LLM 图片解析能力解析每张图片（或 MCP 图片解析工具兜底）
> 5. 将解析结论以 `**[图片解析]**` 形式追加到 `yuque.md` 对应图片下方；无价值图片也需标注 `**[图片解析]** xxx.png: 装饰性图标，无分析价值`
> 6. 更新 `meta.json.parsedImages` 记录解析状态（含每张图的解析结果+时间戳，支持断点续解析）
   - 重点识读对分析有价值的图片（架构图、流程图、时序图、状态机图等），直接分析：
     - 系分文档的设计意图与边界（要解决的问题、约束前提）
     - 方案路径与关键机制（状态流转、时序保证、异常兜底）；若方案图示与文字描述存在差异，以图示为准并标注差异
     - 观测与验证线索（日志关键字、关键字段、判定信号）
     - 配置开关与生效条件（默认值、开关粒度、灰度策略）
     - 图片补充信息（从架构图/流程图/时序图中提取的关键节点、调用链路、关键判断条件等文字中未明确说明的内容）
   - 若有提交 ID → 拉取提交 diff（输出格式参考 [commits-diff.example.md](./assets/example/commits-diff.example.md)，通常包含：变更概览表、按平台/层级分类的文件列表、关键代码对比片段、变更目的说明），直接分析：
     - 涉及平台/层级（如 鸿蒙/iOS/Core C++ 等）及各自受影响文件
     - 变更类型（新增接口、逻辑调整、资源清理、状态管理等）
     - 关键代码变化的实现逻辑与设计意图（尤其是 before/after 对比）
     - 变更目的与解决的问题（从 diff 末尾的目的说明段提取）
   - 若有评审链接 → 读取评审内容（输出格式参考 [review-summary.example.md](./assets/example/review-summary.example.md)，通常包含：问题现象、根因分析、调用链路、解决方案、关键结论、验证建议），直接分析：
     - 缺陷定性与影响范围（功能正确性、稳定性、兼容性）
     - 根因链路与触发条件（最小复现路径、前置条件、触发点）
     - 修复策略与风险（临时补丁/正式修复、回归风险、技术债）
     - 验证闭环与未决项（验证步骤、观察指标、待跟进问题）
   - 对照 Dima 验收标准与代码实现，识别已覆盖/未覆盖改动；对照设计文档与实际变更，识别实现偏差
   - 将本轮详细分析结果按来源拆分写入本地文件：
     - `docs/requirements/<REQ-ID>/sources/dima.md`
     - `docs/requirements/<REQ-ID>/sources/yuque.md`（需包含图片识读结果：每张图片下方以 `**[图片解析]**` 格式标注图片内容摘要；无价值图片标注"无分析价值"；下载失败标注 `[图片解析失败]`）
     - `docs/requirements/<REQ-ID>/sources/commits.md`
     - `docs/requirements/<REQ-ID>/sources/reviews.md`
     - 汇总结论写入 `docs/requirements/<REQ-ID>/analysis-summary.md`
7. **将需求摘要写入 Serena memory**（在数据拉取与分析全部完成、图片解析结论已写入本地文件后执行），以 `req:<REQ-ID>:<类型>` 为文件名区分不同需求：
   - `req:<REQ-ID>:meta` — 需求名称、来源、Dima/语雀链接
   - `req:<REQ-ID>:commits` — 受影响模块、变更类型（若有 commits）
   - `req:<REQ-ID>:design` — 设计意图、技术方案摘要（含图片解析结论）（若有语雀链接）
   - `req:<REQ-ID>:reviews` — 评审结论、遗留问题（若有评审链接）
8. 拉取与分析完成后，**自动进入 analyze 步骤 3**（步骤 1-2 已由 ingest 完成：REQ-ID 已识别、来源文件已就位）；analyze 步骤 3-8 将基于已分析内容深化，输出最终测试分析文档
9. 详细存储格式 → [02-ingestion-and-indexing.md](./references/02-ingestion-and-indexing.md)

### refetch <REQ-ID>

1. 识别输入类型：
   - 提供了 REQ-ID 或需求名称关键词 → 直接匹配对应需求
   - 未提供 → 读取 `.test-assistant/requirements/` 下所有 `meta.json`，按 `updatedAt` 降序，列出最近 5 条供用户选择：
     ```
     请选择要重新拉取的需求（输入编号）：
     1. [REQ-2026-001] 登录模块改造（2026-03-19）
     2. [REQ-2026-002] 支付流程优化（2026-03-18）
     ...
     ```
   - 若 `.test-assistant/requirements/` 为空 → 提示先执行 `ingest`
2. 校验选定需求的来源索引文件 `.test-assistant/requirements/<REQ-ID>/meta.json` 是否存在：
   - 不存在 → 提示先执行 `ingest <REQ-ID or Dima-URL>`
   - 存在 → 继续
3. **强制执行 ingest 第 6 步**（忽略已有拉取缓存，重新拉取并分析）：

   > **💡 需求类型提示（可选）**：同 ingest 第 6 步，在分析开始前可先识别需求类型，决定本次需要重点收集什么维度

   - 重新拉取 Dima 详情、语雀正文、提交 diff、评审内容（以来源索引文件 `meta.json` 中记录链接为准）
   - 对语雀来源必须执行图片解析：提取语雀正文中的全部图片 URL（扩大后的正则），逐一下载到本地后调用 LLM 解析（或 MCP 兜底），将图片结论以 `**[图片解析]**` 形式写入 `docs/requirements/<REQ-ID>/sources/yuque.md` 对应段落；更新 `meta.json.parsedImages` 记录解析状态
   - 按 ingest 第 6 步的分析维度重新生成分析结果
4. 覆盖写入本地文件（按来源拆分）：
   - 更新 `docs/requirements/<REQ-ID>/sources/dima.md`
   - 更新 `docs/requirements/<REQ-ID>/sources/yuque.md`（强制包含图片识读结果：每张图片对应 `**[图片解析]**` 标记）
   - 更新 `docs/requirements/<REQ-ID>/sources/commits.md`
   - 更新 `docs/requirements/<REQ-ID>/sources/reviews.md`
   - 更新汇总结论 `docs/requirements/<REQ-ID>/analysis-summary.md`
5. 数据刷新完成后，**自动进入 analyze 步骤 3**（与 ingest 行为一致，无需用户再次确认）；analyze 步骤 3-8 将基于刚覆写的本地分析文件深化内容，输出最终测试分析文档

### analyze <REQ-ID>

> **执行规则（强制）**：步骤 3-8 必须按顺序依次全部执行，每步开始前必须在对话中输出 `[步骤 N：名称]` 标题；**步骤 7 Review 是强制关卡——步骤 6 草稿输出后，必须先完成步骤 7 自检、再执行步骤 8 Finish，最后才可进入步骤 9 上传；严禁跳步**。

> **跳步借口 vs 现实**（以下任一行为都属于违反规范）：
> | 借口 | 现实 |
> |------|------|
> | "时间紧，差不多就行" | 跳步骤输出的文档质量无法保证，用户最终需要返工 |
> | "这次简单，不需要头脑风暴" | 简单需求更容易遗漏边界场景 |
> | "Review 太耗时，直接跳过" | Review 是强制关卡，跳过 Review 产出的文档不符合 test-assistant 规范 |
> | "用户催了，直接 Finish" | 用户催促不等于可以跳步骤，反而更需要完整输出 |
> | "本地文件有了，直接上传" | 必须 step 9 校验脚本通过才能上传 |
> | "本地已有文件，直接分析" | ingest 生成的文件可能过期或缺失，refetch 可确保数据新鲜度 |
> | "我检查过了，不需要脚本" | validate-test-analysis.sh 验证的是文件内容完整性，人工检查无法替代 |
> | "步骤 3 识别了盲区但数据已有，不用查" | **盲区必须触发步骤 4-5 执行**：识别盲区说明现有数据不足以回答问题，必须制定补充计划并执行收集 |
> | "步骤 4 只写了大纲，没按格式输出" | **步骤 4 必须输出结构化表格**（包含盲区描述/数据来源/检索关键词/预期回答问题），否则步骤 5 无法执行，将阻断进入步骤 6 |
> | "步骤 5 直接说数据已有，跳过核对" | **步骤 5 必须逐条核对步骤 4 的每一条计划**，输出执行了什么检索、检索到了什么结论、是否回答了预期问题；若未按格式输出，将阻断进入步骤 6 |
> | "盲区核对表里有 ❌，但文档没体现" | **❌ 项必须降级为"待确认"**，测试分析文档中必须体现并输出"需补充资源清单"，否则步骤 6 结论校验不通过 |

1. 识别输入类型：
   - 提供了 REQ-ID 或需求名称关键词 → 直接匹配对应需求；若 REQ-ID 格式无效（如为空、含非法字符）或不在 `.test-assistant/requirements/` 中，提示格式要求（`REQ-<YYYYMMDD>-<序号>`）并列出已录入需求供选择
   - 未提供 → 读取 `.test-assistant/requirements/` 下所有 `meta.json`，按 `updatedAt` 降序，列出最近 5 条供用户选择：
     ```
     请选择要分析的需求（输入编号）：
     1. [REQ-2026-001] 登录模块改造（2026-03-19）
     2. [REQ-2026-002] 支付流程优化（2026-03-18）
     ...
     ```
   - 若 `.test-assistant/requirements/` 为空 → 提示先执行 `ingest`
2. 检查本地来源分析文件是否按已录入来源完整可用：
    - **数据来源只能是以下两类路径，不得使用其他来源**：
      - `docs/requirements/<REQ-ID>/sources/` 下的实际分析文件（由 ingest/refetch 生成）
      - `docs/requirements/<REQ-ID>/analysis-summary.md`（汇总结论）
      - **严禁**将 `assets/example/` 目录下的文件当作真实需求数据使用——这些是格式示例/模板，不包含任何真实需求信息
    - 判定规则：仅检查来源索引文件 `meta.json` 中已记录的来源是否存在对应文件
       - 有 `dimaUrl` → 必须存在 `docs/requirements/<REQ-ID>/sources/dima.md`
       - 有 `yuqueUrl` → 必须存在 `docs/requirements/<REQ-ID>/sources/yuque.md` 且 `meta.json` 中存在 `detectedImageUrls` 字段
       - 有 commits → 必须存在 `docs/requirements/<REQ-ID>/sources/commits.md`
       - 有评审链接 → 必须存在 `docs/requirements/<REQ-ID>/sources/reviews.md`
       - **评审记录遗漏检测**：若 `meta.json` 中 `hasReviewRecords: false` 或不存在 `reviews.md`，但 Dima 详情/语雀正文/提交记录中存在评审相关链接（如 CR 链接、review 链接），主动提示：
         "检测到可能存在评审记录但未录入，是否需要补充？"
       - 以上来源文件满足后，还必须存在 `docs/requirements/<REQ-ID>/analysis-summary.md`
    - **不完整或缺失** → 先执行完整的数据拉取与分析流程（同 ingest 第 6 步）：
       - 从来源索引文件 `meta.json` 读取已记录的 `dimaUrl`、`yuqueUrl`、commits 等链接
       - 依次拉取 Dima 详情、语雀正文、提交 diff、评审内容，并在上下文中直接分析
       - 对语雀来源必须执行图片解析：提取语雀正文中的全部图片 URL（扩大后正则），逐一下载后调用 LLM 解析（或 MCP 兜底）；将图片结论以 `**[图片解析]**` 形式写入 `docs/requirements/<REQ-ID>/sources/yuque.md` 对应段落；更新 `meta.json.parsedImages` 记录解析状态
       - 对照验收标准与代码实现识别覆盖点与偏差，将初步分析结论按来源拆分写入：
          - `docs/requirements/<REQ-ID>/sources/dima.md`
          - `docs/requirements/<REQ-ID>/sources/yuque.md`（强制包含图片识读结果：每张图片对应 `**[图片解析]**` 标记；通过 validate-analysis-doc.sh 检测图片解析覆盖率）
          - `docs/requirements/<REQ-ID>/sources/commits.md`
          - `docs/requirements/<REQ-ID>/sources/reviews.md`
          - 并生成汇总结论 `docs/requirements/<REQ-ID>/analysis-summary.md`，后继续后续步骤
   - **完整且可用** → 直接基于 `docs/requirements/<REQ-ID>/sources/*.md` 与 `docs/requirements/<REQ-ID>/analysis-summary.md` 中已有本地分析结果继续，无需重复拉取

   > **⚠️ 步骤 2 与步骤 3 的闭环约束**：步骤 2 的"完整且可用"判定只验证**文件存在性**，不验证**步骤 3 会识别出的盲区是否被覆盖**。当步骤 3 识别出"待查证清单"后，步骤 4-5 必须执行补充数据收集——即使所有源文件都存在，也必须验证现有数据是否覆盖了盲区。详见步骤 4-5 的强制执行约束。

3. **双视角评估 — 头脑风暴**（满足以下任一条件时先执行 `superpowers:brainstorming`，否则直接梳理：涉及 3+ 功能模块、跨平台变更、存在评审记录）：

   > **双视角评估框架**：analyze 流程中，分析工作由两个评估者视角并行推进：
   > - **功能评估者（Feature-Anchor）**：以用户视角为锚点，评估需求的功能完整性、用户体验、用户场景边界
   > - **代码评估者（Change-Anchor）**：以代码变更为锚点，评估变更的技术影响、分支路径、技术风险
   >
   > 两个视角独立工作、独立输出，最终在步骤 5.5 合并。数据获取可并行，分析推理须在单一上下文中串行完成。

   **Feature-Anchor 输出**（功能视角）：
   - 功能分解：按用户旅程/业务流程拆解功能模块
   - 用户场景：列出典型用户场景、边缘用户场景、异常用户场景
   - 生命周期完整性：覆盖"启动→运行→停止→异常→观测"全生命周期
   - 枚举完整性：多值（配置项）、多协议、多厂商、多租户等场景枚举
   - 上下文依赖：识别不清楚的名词/概念，标注"待查证"

   **Change-Anchor 输出**（代码视角）：
   - 变更分解：按 commits.md 和代码 diff 拆解变更文件
   - 分支路径：识别每个变更的技术分支路径（if/else、开关、兼容层）
   - 风险传递：识别代码变更对其他模块的潜在影响
   - 上下文依赖：识别不理解的代码逻辑或技术名词，标注"待查证"

   **⚠️ 盲区识别（不可跳过）**：在输出各自视角结论前，两个评估者须先明确列出"我不理解什么"：
   - Feature-Anchor：我不理解 ______（功能上下文缺口）
   - Change-Anchor：我不理解 ______（代码上下文缺口）
   - 双方将盲区清单合并为"待查证清单"，指导后续数据收集方向
4. **双视角评估 — 规划**（满足以下任一条件时先执行 `superpowers:writing-plans`，否则直接规划：涉及 3+ 功能模块、跨平台变更、存在评审记录）：

   > **⚠️ 强制执行约束**：步骤 3 识别出的"待查证清单"中，**每一条盲区**都必须在步骤 4 中制定对应的补充计划。不能因"文件存在"或"数据已有"而跳过规划——识别盲区本身就说明现有数据不足以回答该问题。

   基于步骤 3 的"待查证清单"，制定双视角的补充数据获取计划：
   - **Feature-Anchor 补充计划**：需要查证的功能上下文（设计文档、需求文档、会议纪要）；**每条盲区都必须有对应计划**，格式示例：
     - 盲区："云端拉流与本地拉流的切换具体时机" → 补充计划："在 yuque 文档中搜索'切换'/'兜底'相关描述，或检索 knowledgeBases 中相关设计文档"
   - **Change-Anchor 补充计划**：需要查证的代码上下文（完整 diff、代码位置、依赖接口）；**每条盲区都必须有对应计划**，格式示例：
     - 盲区："并行失败时的聚合行为" → 补充计划："检索 repositories 中 mediactrl 仓库，定位 ThreadPools 相关代码"
   - 确定测试分析的优先级与结构
5. **双视角评估 — 多线执行收集**（并行时强制先执行 `superpowers:dispatching-parallel-agents`；多任务实现时强制先执行 `superpowers:subagent-driven-development`）：

   > **⚠️ 强制执行约束**：步骤 4 制定的每一条补充计划都必须在步骤 5 中执行。**步骤 5 的输出必须逐条核对步骤 4 的计划**，每条计划的执行结果必须包含：执行了什么检索、检索到了什么结论、该结论是否回答了步骤 4 中"预期回答的问题"。不能因"数据已有"或"现有文档够用"而跳过执行——规划本身就意味着现有数据不足以回答该问题。

   > **⚠️ 步骤 4-5 契约约束**：步骤 4 的输出是步骤 5 的输入，步骤 5 必须逐条核对，不能跳过或合并。

   > **⚠️ 步骤 5 输出格式（建议）**：步骤 5 建议输出结构化的核对结果，格式如下：

   ```
   ## 补充计划执行结果

   ### Feature-Anchor 核对
   | # | 盲区描述 | 执行检索 | 检索结论 | 是否回答了"预期问题" | 状态 |
   |---|----------|----------|----------|---------------------|------|
   | F1 | [盲区1] | MCP工具:[工具名] 仓库/来源:[名称] 关键词:[关键词1,关键词2] | 结论:[具体结论] 来源:[文件:行号] | ✅/❌ | ✅ 已查证 / ❌ 未查证 |

   ### Change-Anchor 核对
   | # | 盲区描述 | 执行检索 | 检索结论 | 是否回答了"预期问题" | 状态 |
   |---|----------|----------|----------|---------------------|------|
   | C1 | [盲区1] | MCP工具:[工具名] 仓库/来源:[名称] 关键词:[关键词1,关键词2] | 结论:[具体结论] 来源:[文件:行号或代码位置] | ✅/❌ | ✅ 已查证 / ❌ 未查证 |

   ### 待确认清单（来自 ❌ 项）
   - [ ] [盲区描述] → 需补充：[缺少的资源类型]
   ```

   **⚠️ 数据写入约定**：数据收集可并行，但写入本地文件须在步骤 6 主流程中顺序完成，避免并发写入冲突。

   **来源选择优先级**：优先使用 `.test-assistant/config.json` 中已配置的数据源进行检索（`knowledgeBases`、`repositories`、`yuqueNamespaces`、`testKnowledgeBases`、`testReportYuqueUrls`、`testCodeRepos`）；仅当配置源缺失或结果不足时，再补充临时来源

   **按可信度层级检索**（代码 → 文档 → 概览 → 通用知识）

   **识别实现与文档的差异点**，标注冲突与置信度来源

   **⚠️ 上下文追溯要求**：每个结论须追溯到具体来源文件位置（而非泛泛而谈）。若某结论无法追溯，标注为"待确认"并输出"需补充资源清单"

   - 若某类数据缺失（如无提交记录），标注缺失并继续，不阻断

5.5. **Duality-Merge（双视角合并）**：

   合并 Feature-Anchor 和 Change-Anchor 两个视角的输出，消除重复、解决冲突：
   - **重复合并**：同一测试点从两个视角独立发现 → 合并为单一测试点，标注双视角共同覆盖
   - **冲突解决**：两个视角对同一场景的预期结果不一致 → 标注冲突点，输出为"待确认"，并列出需补充验证的信息
   - **盲区补充**：基于步骤 5 的核对结果，将步骤 5 输出表格中的状态列汇总：
     - 所有 ✅ 项 → 标记为"✅ 已查证"，注明覆盖来源
     - 所有 ❌ 项 → 标记为"❌ 待确认"，并汇总到"待确认清单"

   > **⚠️ 步骤 5.5 输出格式（建议）**：步骤 5.5 建议输出盲区核对汇总，格式如下：

   ```
   ## 盲区核对汇总

   | # | 盲区描述 | 来源视角 | 覆盖状态 | 来源文件 | MCP工具 | 来源位置 |
   |---|----------|----------|----------|----------|----------|----------|
   | 1 | [盲区1] | Feature/Change | ✅ 已查证 / ❌ 待确认 | [文件名] | [工具名] | [行号或代码位置] |

   ## 待确认清单（来自 ❌ 项）
   - [ ] [盲区描述] → 需补充：[缺少的资源类型]
   ```

   > **⚠️ 进入步骤 6 的前置条件（建议）**：步骤 5.5 的盲区核对汇总表中，**所有盲区建议已核对**（不能有空白状态）。若有 ❌ 项，必须在步骤 6 的结论校验中体现为"待确认"，并输出"需补充资源清单"后方可继续。

6. **执行（如需实现/修复逻辑：强制先执行 `superpowers:test-driven-development`，再执行 `superpowers:executing-plans`）**：

   以 `docs/requirements/<REQ-ID>/sources/*.md` 与 `docs/requirements/<REQ-ID>/analysis-summary.md` 中已保存的详细分析资料为主要依据，基于步骤 5.5 合并后的双视角结论，综合所有收集结果，生成结构化测试分析文档草稿，包含以下四个必需章节：变更范围、风险点、测试建议、测试步骤

   **结论校验**：逐条校验每个结论是否有来自配置来源的证据支撑；无支撑则降级为”待确认”，并输出”需补充资源清单”（缺少的知识库 ID、语雀链接、仓库地址或评审记录）后再继续

   > **⚠️ 结论校验规范**：
   > - 未查证的盲区 → 必须标注为”待确认”
   > - “待确认”项 → 必须输出”需补充资源清单”

   **⚠️ 强制快速自检（不可跳过）**：在输出草稿前，逐项确认以下问题：
   - [ ] 是否逐个验证了 commits.md 中的变更文件都有对应测试覆盖？
   - [ ] 是否逐个验证了 Dima 验收标准都有对应测试验证？
   - [ ] 是否有测试点的上下文来源追溯到了具体文件位置（而非泛泛而谈）？
   - [ ] 是否有测试点因上下文不足被标注为”待确认”并列出待补充清单？
   - [ ] 是否所有测试点都包含了前置条件、输入数据、预期输出？
   - [ ] 步骤 5.5 的 Duality-Merge 是否已解决所有冲突和重复？
   - [ ] Feature-Anchor 和 Change-Anchor 两个视角是否都有测试点覆盖？
   - [ ] **是否已根据需求类型关注了对应扩展维度？**（架构/协议/超时/错误传播/观测线索/并发模型）
   - [ ] **是否已核对步骤 4 补充计划清单中的每一条盲区？** 步骤 5 必须逐条执行并输出核对结果，不能跳过或合并——这是步骤 6 结论校验的前置依赖
   - [ ] **若步骤 5 有 ❌ 项（未查证的盲区），测试分析文档中是否已将此类测试点降级为”待确认”并输出了”需补充资源清单”？**
   - [ ] 若有任意一项为”否”，先修正再继续输出草稿。
7. **Review（强制先执行 `superpowers:verification-before-completion`，如有审查流程再执行 `superpowers:requesting-code-review` / `superpowers:receiving-code-review`）**：对草稿进行自我检查；**必须在对话中以表格形式逐项输出真实自检结论（不得全填 ✅ 而不实际检查），全部 ✅ 后才可继续步骤 8**：

   > **⚠️ 规范约定：步骤 7 Review 是强制关卡，严禁跳过直接进入步骤 8。**跳过 review 即违反 test-assistant 操作规范，产出的测试分析报告质量无法保证。

   **完整性检查（每条测试点必须满足）：**
   | 检查项 | 结论（✅ / ⚠️ / ❌） | 问题说明 |
   |--------|---------------------|----------|
   | 每个测试点有明确的前置条件 | | |
   | 每个测试点有明确的输入数据 | | |
   | 每个测试点有明确的预期输出 | | |
   | 每个测试点有对应的来源证据（代码位置/文档章节/评审意见） | | |
   | 边界值测试点有具体的边界值说明 | | |
   | 异常场景测试点有具体的触发条件说明 | | |

   **覆盖率交叉验证：**
   | 检查项 | 结论（✅ / ⚠️ / ❌） | 问题说明 |
   |--------|---------------------|----------|
   | commits.md 中的每个变更文件都有对应测试点覆盖 | | |
   | 变更类型（新增/修改/删除/兼容）均有对应测试 | | |
   | Dima 验收标准中的每个条件都有对应测试验证 | | |
   | 语雀文档中的每个设计要点都有测试覆盖 | | |
   | 评审意见中的每个风险点都有测试覆盖 | | |

   **优先级与上下文追溯：**
   | 检查项 | 结论（✅ / ⚠️ / ❌） | 问题说明 |
   |--------|---------------------|----------|
   | 风险优先级（P0/P1/P2/P3）有明确划分依据 | | |
   | 每个测试点的上下文可追溯到具体来源文件和位置 | | |
   | 若测试点上下文不足，已触发补充查找（config.json 来源检索） | | |
   | 缺失上下文的测试点已标注为"待确认"并输出待补充资源清单 | | |

   **可执行性检查：**
   | 检查项 | 结论（✅ / ⚠️ / ❌） | 问题说明 |
   |--------|---------------------|----------|
   | 测试步骤清晰可执行，无模糊描述 | | |
   | 涉及环境/配置变更的测试有明确的准备步骤 | | |
   | 涉及多系统交互的测试有明确的调用链路说明 | | |

   - 有 ⚠️ 或 ❌ 项 → 先在草稿中修正对应内容，修正后重新输出清单，全部 ✅ 后再继续

   - **Step 7 末段验证（草稿提交 review 前）**：执行 [validate-test-analysis.sh](./scripts/validate-test-analysis.sh) 验证文件内容完整性；若脚本输出 WARNING 且指向具体问题，先修正后再继续
   - **仅当清单全部 ✅ 且脚本无 ERROR 输出时，方可进入步骤 8**

   > **⚠️ 规范约定：跳过上表任一检查项、或未逐项输出结论即进入步骤 8 的行为，不符合 test-assistant 规范。**
8. **Finish（需要分支收尾时强制执行 `superpowers:finishing-a-development-branch`）**：输出最终测试分析文档，并同步保存本地 Markdown 文件 `docs/requirements/<REQ-ID>/test-analysis.md`；文档中的结论须可回溯到 `docs/requirements/<REQ-ID>/sources/*.md` 或 `docs/requirements/<REQ-ID>/analysis-summary.md`
9. 输出完成后，上传前必须先执行两个校验脚本：
   - [validate-analysis-doc.sh](./scripts/validate-analysis-doc.sh)：检查图片解析覆盖率（针对语雀文档中的图片）
   - [validate-test-analysis.sh](./scripts/validate-test-analysis.sh)：再次验证测试分析文档内容完整性（与 step 7 自检互为补充）
   - 两个脚本均通过（退出码 0）→ 继续上传流程
   - 任一脚本校验失败（非 0）→ 先修复文档问题后再进入上传流程
10. 询问用户是否上传到语雀：
   - 读取 `.test-assistant/config.json` 中的 `testReportYuqueUrls`：
     - 已配置且不是占位值 → 展示地址列表供选择，并询问是否上传
     - 未配置或仍是占位值 → 先询问目标语雀空间 URL，并询问是否保存到 `config.json`
   - 用户确认上传 → 将本地文件 `docs/requirements/<REQ-ID>/test-analysis.md` 中的 Markdown 正文上传至目标语雀空间，标题格式：`【测试分析】<需求名称> <YYYYMMDD>`
   - 用户拒绝或跳过 → 不上传，结束流程
11. 详细流程 → [03-query-and-answer.md](./references/03-query-and-answer.md)

## Credibility Levels

| Level | 来源 |
|-------|------|
| 1（最高）| 代码、提交记录、显式配置 |
| 2 | 设计文档、Dima、评审记录 |
| 3 | 仓库概览、语雀概览、知识库检索 |
| 4 | 通用知识 |

冲突规则：Level 1 优先；同层级按更新时间优先；输出中必须标注冲突点与最终结论；关键结论须附来源与可信度层级。

## Scripts

| 脚本 | 用途 |
|------|------|
| [init-workspace.sh](./scripts/init-workspace.sh) | 初始化 `.test-assistant/` 目录 |
| [validate-config.sh](./scripts/validate-config.sh) | 校验配置 JSON |
| [check-mcps.sh](./scripts/check-mcps.sh) | 检查必需 MCP |
| [rag-status.sh](./scripts/rag-status.sh) | 检查 Serena 索引健康状态 |
| [validate-analysis-doc.sh](./scripts/validate-analysis-doc.sh) | 上传前校验测试分析文档图片解析覆盖率 |
| [validate-test-analysis.sh](./scripts/validate-test-analysis.sh) | step 7 自检后 + step 9 上传前校验测试分析文档内容完整性 |

详见 [scripts/README.md](./scripts/README.md)

## References

- [01-bootstrap-and-config.md](./references/01-bootstrap-and-config.md) — 启动与配置
- [02-ingestion-and-indexing.md](./references/02-ingestion-and-indexing.md) — 采集与索引
- [03-query-and-answer.md](./references/03-query-and-answer.md) — 查询与回答
- [04-ops-and-diagnostics.md](./references/04-ops-and-diagnostics.md) — 运维与诊断
- [skill-modules-overview.md](./references/skill-modules-overview.md) — 模块架构与边界规则
