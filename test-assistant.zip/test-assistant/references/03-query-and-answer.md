# Module 03: Query And Answer

## Goal

Provide accurate responses using credibility-first retrieval and explicit conflict handling.

## Scope

- Intent classification
- Retrieval orchestration
- Credibility scoring and source labeling
- Final answer synthesis

## Inputs

- User query
- Saved local analysis files under `docs/requirements/<REQ-ID>/sources/*.md`
- Saved local summary file `docs/requirements/<REQ-ID>/analysis-summary.md`
- Cached overview files
- Serena memory data
- Runtime config

## Retrieval Order

1. Level 1: actual code, commit records, explicit config sources
2. Level 2: design docs, Dima details, review records
3. Level 3: repo/wiki overviews, yuque overviews, KB summaries
4. Level 4: generic knowledge

## Conflict Policy

1. Prefer Level 1 over other levels.
2. Prefer explicit configuration over inference.
3. Prefer newer data for same-level conflicts.
4. Always label conflict and chosen resolution.

## Answer Contract

1. Include source labels with credibility level.
2. Separate facts from assumptions.
3. If evidence is insufficient, state what is missing.
4. For operational actions, provide direct next command.
5. When generating a test analysis document, use the saved local analysis files under `docs/requirements/<REQ-ID>/sources/*.md` and `docs/requirements/<REQ-ID>/analysis-summary.md` as the primary basis, and keep conclusions traceable to those files.

## Non-goals

- No ingestion execution.
- No startup checks.
