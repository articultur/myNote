# Test Assistant Skill Modules

This folder defines the split architecture for test-assistant so that long-form behavior can be maintained in smaller, stable modules.

## Module Map

- [01-bootstrap-and-config.md](01-bootstrap-and-config.md)
  - Startup bootstrap, config loading, config validation, MCP dependency checks.
- [02-ingestion-and-indexing.md](02-ingestion-and-indexing.md)
  - Daily overview refresh, requirement ingestion, RAG write path and state update.
- [03-query-and-answer.md](03-query-and-answer.md)
  - Credibility-layer retrieval strategy, conflict handling, answer rendering contract.
- [04-ops-and-diagnostics.md](04-ops-and-diagnostics.md)
  - Health checks, reconfiguration, recovery, and troubleshooting protocol.

## Boundary Rules

1. Bootstrap module is the only module allowed to mutate startup state directly.
2. Ingestion module is the only module allowed to write RAG data and rag-status.
3. Query module is read-only for cached data and memory content.
4. Ops module can orchestrate scripts but cannot bypass validation contracts.

## Runtime Orchestration

1. Run module 01 first on every `/test-assistant` startup.
2. Run module 02 only if update/initialization is needed.
3. Run module 03 to serve user requests.
4. Run module 04 on explicit maintenance commands or when failures happen.

## Script Dependencies

- `scripts/init-workspace.sh`
- `scripts/validate-config.sh`
- `scripts/check-mcps.sh`
- `scripts/rag-status.sh`

## Versioning

- Module docs version: `2026-03-19-split-v1`
- Owner: test-assistant maintainers
