# Module 01: Bootstrap And Config

## Prerequisites

首次使用前需安装依赖 skills（在 Claude 中执行）：

```
claude skill install superpower
claude skill install serena
```

## Goal

Ensure startup is deterministic and safe before any retrieval or indexing action.

## Scope

- CLAUDE guide bootstrap
- Workspace skeleton init
- Config load and schema validation
- MCP dependency check
- Serena/RAG freshness check and startup-triggered overview refresh decision

## Inputs

- Workspace root
- `.test-assistant/config.json`
- `CLAUDE.md`

## Outputs

- Valid runtime config object
- MCP check report
- Overview refresh decision and execution status
- Startup decision: continue or degraded mode

## Commands

```bash
./scripts/init-workspace.sh
./scripts/validate-config.sh ./.test-assistant/config.json
./scripts/check-mcps.sh ./.test-assistant/config.json
./scripts/rag-status.sh ./.test-assistant
```

## Decision Contract

1. If config validation fails: stop startup and ask user to fix config.
2. If required MCP is missing: continue in degraded mode and present install command.
3. If `rag-status` suggests update or overview files are missing: run module 02 overview generation/refresh first.
4. If all checks pass and overviews are ready: proceed to module 03.

## Failure Handling

- `validate-config.sh` non-zero: return field-level errors to user.
- `check-mcps.sh` exit `2`: mark MCP status unknown and continue with warning.
- `check-mcps.sh` exit `3`: mark missing MCP list and continue with warning.

## Non-goals

- No data ingestion.
- No query answering.
- No requirement-level source analysis write.
