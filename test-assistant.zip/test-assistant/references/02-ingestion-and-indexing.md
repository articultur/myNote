# Module 02: Ingestion And Indexing

## Goal

Guide users through structured requirement data entry and persist all artifacts for downstream analysis.

## Input Resolution

`ingest` 入参支持两种格式：

| 输入内容 | 处理方式 |
|------------|----------|
| 纯 ID（如 `2026022800114357381`） | 直接使用为 REQ-ID |
| `project.alipay.com` URL | 提取 `openWorkItemId` 作为 REQ-ID，自动拉取 Dima 详情 |

URL 示例：
```
https://project.alipay.com/space/W24001007150/sprint/detail?openWorkItemId=2026022800114357381&...
                                                                            ^^^^^^^^^^^^^^^^^^^
                                                                            提取此字段为 REQ-ID
```

## Guided Ingest Flow

执行 `ingest <REQ-ID>` 后按以下顺序逐步引导：

```
[1/5] 需求名称？（必填）
[2/5] Dima 需求 URL 或 ID？（跳过请回车）
      └→ 填写后自动拉取 Dima 需求详情
[3/5] 语雀文档链接？（跳过请回车）
      └→ 填写后自动读取语雀正文
[4/5] 代码提交 ID？（多个用逗号分隔，跳过请回车）
[5/5] 设计文档 / 评审记录链接？（跳过请回车）
```

全部回答完成后输出录入摘要并提示可执行 `analyze <REQ-ID>`。

## Overview Refresh Contract (Init Trigger)

当初始化阶段判定 `rag-status` 需要更新或发现概览缺失时，必须先执行概览刷新，再进入查询/分析。

来源范围（按配置项）：

- 开发侧：`knowledgeBases`、`repositories`、`yuqueNamespaces`
- 测试侧：`testKnowledgeBases`、`testCodeRepos`、`testReportYuqueUrls`

写入要求：

1. 在 `.test-assistant/overviews/` 为每个已配置来源生成对应概览文件。
2. 对不可访问、无权限或空配置来源，输出失败原因并保留其余来源成功结果。
3. 刷新完成后更新 `.test-assistant/rag-status.json` 的 `indexedSources`/`memoryCount` 与 `.test-assistant/last-update.json` 对应时间戳。

文件命名规范（强制）：

1. 统一命名格式：`<domain>__<sourceType>__<sourceId>.md`
2. 字段取值：
   - `domain`：`dev` / `test`
   - `sourceType`：`kb` / `repo` / `yuque`
   - `sourceId`：来源唯一标识的归一化结果（小写、非字母数字替换为 `-`、去除首尾 `-`）
3. 冲突处理：若 `sourceId` 归一化后重复，追加短哈希后缀，确保不同来源不会覆盖。

## Storage Layout

```
.test-assistant/requirements/<REQ-ID>/
└── meta.json          # 需求元信息（格式参考 [meta.example.json](../assets/example/meta.example.json)）

docs/requirements/<REQ-ID>/
├── sources/
│   ├── dima.md        # Dima 来源分析
│   ├── yuque.md       # 语雀来源分析
│   ├── commits.md     # 提交 diff 来源分析
│   └── reviews.md     # 评审记录来源分析
├── analysis-summary.md # 多来源汇总结论
└── test-analysis.md   # 最终测试分析文档 Markdown
```

## Serena Memory Key Convention

所有写入 Serena 的条目均以 `req:<REQ-ID>:<类型>` 为文件名，通过文件名区分不同需求的记录。

| Key | 内容 |
|-----|------|
| `req:<REQ-ID>:meta` | 需求元信息摘要（名称、来源、Dima/语雀链接） |
| `req:<REQ-ID>:commits` | 提交记录摘要（受影响模块、变更类型） |
| `req:<REQ-ID>:design` | 设计文档摘要（设计意图、技术方案、涉及模块） |
| `req:<REQ-ID>:reviews` | 评审记录摘要（评审结论、遗留问题） |

## Write Contract

1. 先写本地文件（`docs/requirements/<REQ-ID>/sources/*.md`、`analysis-summary.md` 与 `test-analysis.md`），再写 Serena memory 摘要。
2. `indexedSources` 仅在全部写入成功后更新。
3. `lastUpdatedAt` 在整个 run 成功结束后更新。
4. 部分失败时记录失败项，不回滚已成功写入。

## Scope

- Overview generation and refresh
- Requirement data ingestion
- Serena memory writes
- rag-status update

## Non-goals

- No user-facing final answer synthesis.
- No startup config mutation.
