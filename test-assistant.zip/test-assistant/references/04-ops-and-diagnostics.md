# Module 04: Ops And Diagnostics

## Goal

Standardize maintenance and recovery flows with script-first operations.

## Scope

- Health checks
- Reconfiguration
- Rebuild and retry operations
- Failure triage

## Core Commands

```bash
./scripts/validate-config.sh ./.test-assistant/config.json
./scripts/check-mcps.sh ./.test-assistant/config.json
./scripts/rag-status.sh ./.test-assistant
```

## Troubleshooting Matrix

| 症状 | 脚本退出码 | 处理 |
|------|-----------|------|
| Config invalid | `validate-config.sh` exit 1 | 修复字段类型或必填项 |
| Required MCP missing | `check-mcps.sh` exit 3 | 执行 config 中的 `installCommand` |
| RAG stale or incomplete | `rag-status.sh` exit 2 | 执行 RAG 更新流程后重查 |
| `claude` CLI missing | `check-mcps.sh` exit 2 | 将 `claude` 加入 PATH |

## Recovery Playbook

1. Re-init workspace if artifacts missing.
2. Re-validate config.
3. Re-check MCP dependencies.
4. Re-run RAG update.
5. Re-run rag-status.

## Non-goals

- No answer generation policy definition.
- No source-priority algorithm changes.
