#!/usr/bin/env bash
set -euo pipefail

WORKDIR="${1:-.test-assistant}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

mkdir -p "${WORKDIR}"/{overviews,requirements}

copy_if_missing() {
  local src="$1"
  local dst="$2"
  if [[ -f "${dst}" ]]; then
    return 0
  fi
  cp "${src}" "${dst}"
}

copy_if_missing "${ROOT_DIR}/assets/config.example.json" "${WORKDIR}/config.json"
copy_if_missing "${ROOT_DIR}/assets/last-update.example.json" "${WORKDIR}/last-update.json"
copy_if_missing "${ROOT_DIR}/assets/rag-status.example.json" "${WORKDIR}/rag-status.json"

if [[ -d "${ROOT_DIR}/assets/example" ]]; then
  mkdir -p "${WORKDIR}/requirements/example/reviews"
  copy_if_missing "${ROOT_DIR}/assets/example/meta.example.json" "${WORKDIR}/requirements/example/meta.json"
  copy_if_missing "${ROOT_DIR}/assets/example/commits.example.json" "${WORKDIR}/requirements/example/commits.json"
  copy_if_missing "${ROOT_DIR}/assets/example/design-doc.example.md" "${WORKDIR}/requirements/example/design-doc.md"
  copy_if_missing "${ROOT_DIR}/assets/example/reviews/design-review.example.md" "${WORKDIR}/requirements/example/reviews/design-review.md"
fi

echo "Initialized workspace at ${WORKDIR}"
