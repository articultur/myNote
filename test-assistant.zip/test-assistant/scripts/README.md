# Scripts

These scripts make test-assistant setup and health checks repeatable.

## Script List

- `init-workspace.sh [workdir]`
  - Initialize `.test-assistant` directory structure and copy example files when missing.
- `validate-config.sh [config-path]`
  - Validate config schema and required fields.
- `check-mcps.sh [config-path]`
  - Compare configured MCPs with installed MCPs from `claude mcp list`.
- `rag-status.sh [workdir]`
  - Check Serena index health and whether overviews look up-to-date.
- `validate-analysis-doc.sh <REQ-ID> [workdir] [doc-root]`
  - Validate requirement analysis docs before upload (required files, non-empty content, yuque image parsing marker, traceability hints).

## Quick start

```bash
chmod +x scripts/*.sh
./scripts/init-workspace.sh
./scripts/validate-config.sh
./scripts/check-mcps.sh
./scripts/rag-status.sh
./scripts/validate-analysis-doc.sh REQ-2026-001
```

## Exit codes

- `validate-config.sh`
  - `0`: valid
  - `1`: invalid config or parse error
- `check-mcps.sh`
  - `0`: all required MCPs installed or no MCP config
  - `1`: invalid config format
  - `2`: `claude` command not found
  - `3`: missing required MCPs
- `rag-status.sh`
  - `0`: healthy
  - `1`: status file missing or parse error
  - `2`: update suggested
- `validate-analysis-doc.sh`
  - `0`: validation passed (may include warnings)
  - `1`: validation failed or input invalid
