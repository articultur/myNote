#!/usr/bin/env bash
set -euo pipefail

WORKDIR="${1:-.test-assistant}"
RAG_STATUS_PATH="${WORKDIR}/rag-status.json"
OVERVIEWS_DIR="${WORKDIR}/overviews"

if [[ ! -f "${RAG_STATUS_PATH}" ]]; then
  echo "ERROR: rag-status not found: ${RAG_STATUS_PATH}" >&2
  exit 1
fi

python3 - "$RAG_STATUS_PATH" "$OVERVIEWS_DIR" "$WORKDIR" <<'PY'
import datetime as dt
import json
import pathlib
import re
import sys

rag_path = pathlib.Path(sys.argv[1])
overviews_dir = pathlib.Path(sys.argv[2])
WORKDIR = pathlib.Path(sys.argv[3])

def parse_iso(s: str):
    if not s:
        return None
    s = s.replace("Z", "+00:00")
    try:
        return dt.datetime.fromisoformat(s)
    except ValueError:
        return None

try:
    status = json.loads(rag_path.read_text(encoding="utf-8"))
except Exception as exc:
    print(f"ERROR: invalid rag-status json: {exc}", file=sys.stderr)
    sys.exit(1)

initialized = bool(status.get("initialized", False))
last_updated = parse_iso(status.get("lastUpdatedAt", ""))
indexed = status.get("indexedSources", [])
memory_count = status.get("memoryCount", {})

print("RAG status summary:")
print(f"  - initialized: {initialized}")
print(f"  - lastUpdatedAt: {status.get('lastUpdatedAt', '') or '(empty)'}")
print(f"  - indexedSources: {indexed}")
print(f"  - memoryCount: {memory_count}")

required_sources = ["dima", "commits", "repo-overview", "design-docs"]
missing = [s for s in required_sources if s not in indexed]
if missing:
    print(f"  - missing indexed sources: {missing}")

# 从 config.json 读取已配置来源列表，检查概览文件是否一一对应
config_path = WORKDIR.parent / ".test-assistant" / "config.json"
if config_path.exists():
    try:
        config = json.loads(config_path.read_text(encoding="utf-8"))
    except Exception:
        config = {}
else:
    config = {}

dev_sources = []
for kb in config.get("knowledgeBases", []):
    dev_sources.append(("kb", kb))
for repo in config.get("repositories", []):
    dev_sources.append(("repo", repo))
for ns in config.get("yuqueNamespaces", []):
    dev_sources.append(("yuque", ns))

test_sources = []
for kb in config.get("testKnowledgeBases", []):
    test_sources.append(("kb", kb))
for repo in config.get("testCodeRepos", []):
    test_sources.append(("repo", repo))
for url in config.get("testReportYuqueUrls", []):
    test_sources.append(("yuque", url))

# 检查概览文件存在性（使用 step 6 的命名规范）
# 格式: <domain>__<sourceType>__<sourceId>.md
# 归一化规则：保留 __ 作为组件分隔符，sourceId 中的非字母数字转 -，多个连续分隔符合并
def normalize_source_id(s: str) -> str:
    # 小写，将非字母数字字符替换为单个 -，合并多个分隔符
    s = s.lower()
    # 移除常见协议前缀
    s = re.sub(r'^(https?://|git@)', '', s)
    # 替换非字母数字字符为 -
    s = re.sub(r'[^a-z0-9]+', '-', s)
    # 移除 .git 后缀
    s = re.sub(r'\.git$', '', s)
    # 合并多个连续的分隔符，去除首尾 -
    s = re.sub(r'-+', '-', s).strip('-')
    return s

missing_overviews = []
for domain, source_type, source_id in (
    [("dev", st, src) for st, src in dev_sources] +
    [("test", st, src) for st, src in test_sources]
):
    normalized = f"{domain}__{source_type}__{normalize_source_id(source_id)}"
    overview_file = overviews_dir / f"{normalized}.md"
    if not overview_file.exists():
        missing_overviews.append(f"{normalized}.md")

if missing_overviews:
    print(f"  - missing overview files: {missing_overviews}")
else:
    print("  - missing overview files: none")

if overviews_dir.exists():
    files = sorted([p for p in overviews_dir.glob("*.md") if p.is_file()])
else:
    files = []

print(f"  - overview files: {len(files)}")

now = dt.datetime.now()
OVERVIEW_MAX_AGE_HOURS = 24
outdated = []
for f in files:
    mtime = dt.datetime.fromtimestamp(f.stat().st_mtime)
    age_hours = (now - mtime).total_seconds() / 3600
    if age_hours > OVERVIEW_MAX_AGE_HOURS:
        outdated.append(f.name)

if outdated:
    print(f"  - outdated overviews: {outdated}")
else:
    print("  - outdated overviews: none")

has_configured_sources = bool(dev_sources or test_sources)
if has_configured_sources and missing_overviews:
    print(f"\nERROR: {len(missing_overviews)} configured source(s) missing overview file(s).")
    sys.exit(1)

need_update = (not initialized) or bool(missing) or bool(outdated) or bool(missing_overviews)
if need_update:
    print("\nRAG update suggested.")
    sys.exit(2)

if last_updated is None:
    print("\nRAG update suggested: lastUpdatedAt is invalid or empty.")
    sys.exit(2)

print("\nRAG state looks healthy.")
PY
