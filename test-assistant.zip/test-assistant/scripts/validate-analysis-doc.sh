#!/usr/bin/env bash
set -euo pipefail

REQ_ID="${1:-}"
WORKDIR="${2:-.test-assistant}"
DOC_ROOT="${3:-docs/requirements}"

if [[ -z "${REQ_ID}" ]]; then
  echo "Usage: $0 <REQ-ID> [workdir] [doc-root]" >&2
  echo "Example: $0 REQ-2026-001 .test-assistant docs/requirements" >&2
  exit 1
fi

META_PATH="${WORKDIR}/requirements/${REQ_ID}/meta.json"
REQ_DIR="${DOC_ROOT}/${REQ_ID}"
SOURCES_DIR="${REQ_DIR}/sources"
SUMMARY_PATH="${REQ_DIR}/analysis-summary.md"
ANALYSIS_PATH="${REQ_DIR}/test-analysis.md"

if [[ ! -f "${META_PATH}" ]]; then
  echo "ERROR: meta.json not found: ${META_PATH}" >&2
  exit 1
fi

python3 - "${REQ_ID}" "${META_PATH}" "${SOURCES_DIR}" "${SUMMARY_PATH}" "${ANALYSIS_PATH}" <<'PY'
import json
import pathlib
import re
import sys

req_id = sys.argv[1]
meta_path = pathlib.Path(sys.argv[2])
sources_dir = pathlib.Path(sys.argv[3])
summary_path = pathlib.Path(sys.argv[4])
analysis_path = pathlib.Path(sys.argv[5])

errors = []
warnings = []

try:
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
except Exception as exc:
    print(f"ERROR: invalid json in {meta_path}: {exc}", file=sys.stderr)
    sys.exit(1)

def has_value(v):
    return isinstance(v, str) and bool(v.strip())

need_dima = has_value(meta.get("dimaUrl", ""))
need_yuque = has_value(meta.get("yuqueUrl", ""))
need_commits = bool(meta.get("hasCommits", False))
need_reviews = bool(meta.get("hasReviewRecords", False))

required_files = [
    (summary_path, "analysis-summary.md"),
    (analysis_path, "test-analysis.md"),
]

if need_dima:
    required_files.append((sources_dir / "dima.md", "sources/dima.md"))
if need_yuque:
    required_files.append((sources_dir / "yuque.md", "sources/yuque.md"))
if need_commits:
    required_files.append((sources_dir / "commits.md", "sources/commits.md"))
if need_reviews:
    required_files.append((sources_dir / "reviews.md", "sources/reviews.md"))

for p, name in required_files:
    if not p.exists():
        errors.append(f"missing required file: {name} ({p})")
        continue
    txt = p.read_text(encoding="utf-8").strip()
    if not txt:
        errors.append(f"empty required file: {name} ({p})")

if analysis_path.exists():
    analysis_text = analysis_path.read_text(encoding="utf-8")
    if len(analysis_text.strip()) < 80:
        warnings.append("test-analysis.md is very short (< 80 chars)")

    # Minimal structural checks for test analysis quality.
    section_rules = [
        r"变更范围",
        r"风险",
        r"测试",
    ]
    for pat in section_rules:
        if not re.search(pat, analysis_text):
            warnings.append(f"test-analysis.md may miss section keyword: {pat}")

if need_yuque:
    yuque_path = sources_dir / "yuque.md"
    if yuque_path.exists():
        yuque_text = yuque_path.read_text(encoding="utf-8")
        import re as _re

        # 优先使用双向验证（meta.json 中有 detectedImageUrls 时）
        # 无 detectedImageUrls 时回退到原有 has_images 正则检测（兼容旧数据）
        detected_count = len(meta.get("detectedImageUrls", []))
        if detected_count > 0:
            # 双向验证：detected vs parsed 数量比对
            parsed_count = yuque_text.count("[图片解析]")
            if detected_count > parsed_count:
                errors.append(
                    f"有 {detected_count - parsed_count} 张图片未解析，请先完成图片解析"
                )
            elif parsed_count > detected_count:
                errors.append(
                    f"发现 {parsed_count - detected_count} 张图片未被检测到（可能被遗漏），"
                    "请补充检测规则或移除多余标记"
                )
        else:
            # 回退到原有检测逻辑（兼容无 detectedImageUrls 的旧数据）
            has_images = bool(_re.search(r"!\[.*?\]\(https?://\S+\)|<img\s", yuque_text))
            if has_images and "[图片解析]" not in yuque_text:
                errors.append(
                    "yuque.md contains image URLs but is missing the '[图片解析]' marker — "
                    "run image parsing and append results before uploading"
                )
            # elif not has_images and "[图片解析]" not in yuque_text: pass  # 省略，隐式 pass

if summary_path.exists() and analysis_path.exists():
    summary_text = summary_path.read_text(encoding="utf-8")
    analysis_text = analysis_path.read_text(encoding="utf-8")
    if len(summary_text.strip()) > 0 and len(analysis_text.strip()) > 0:
        # Encourage traceability hints in final doc.
        trace_hints = ["sources/", "analysis-summary", "来源", "证据"]
        if not any(h in analysis_text for h in trace_hints):
            warnings.append("test-analysis.md has weak traceability hints (no sources/analysis-summary/来源/证据)")

if errors:
    print(f"Validation failed for {req_id}:", file=sys.stderr)
    for item in errors:
        print(f"  - {item}", file=sys.stderr)
    if warnings:
        print("Warnings:", file=sys.stderr)
        for item in warnings:
            print(f"  - {item}", file=sys.stderr)
    sys.exit(1)

print(f"Validation passed for {req_id}.")
if warnings:
    print("Warnings:")
    for item in warnings:
        print(f"  - {item}")
PY
