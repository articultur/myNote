#!/usr/bin/env bash
# 用法: ./download-images.sh <image-url> <output-dir> <filename>
# 失败时返回 exit 1，成功时输出文件路径

set -euo pipefail

URL="$1"
OUTPUT_DIR="$2"
FILENAME="$3"
MAX_RETRIES=3
RETRY_DELAY=2

mkdir -p "$OUTPUT_DIR"

# 下载（重试逻辑）
for i in $(seq 1 $MAX_RETRIES); do
  if curl -L "$URL" -o "${OUTPUT_DIR}/${FILENAME}" --max-time 30 --fail 2>/dev/null; then
    break
  fi
  if [[ $i -lt $MAX_RETRIES ]]; then
    echo "Download failed, retrying ($i/$MAX_RETRIES)..." >&2
    sleep $RETRY_DELAY
  else
    echo "ERROR: Failed to download after $MAX_RETRIES attempts" >&2
    exit 1
  fi
done

# 校验是否为有效图片（跨平台兼容）
MIME_TYPE=$(file -b --mime-type "${OUTPUT_DIR}/${FILENAME}" 2>/dev/null || echo "unknown")
case "$MIME_TYPE" in
  image/png|image/jpeg|image/gif|image/webp|image/svg+xml|image/bmp)
    echo "${OUTPUT_DIR}/${FILENAME}"
    ;;
  *)
    echo "ERROR: Downloaded file is not a valid image (mime: $MIME_TYPE)" >&2
    exit 1
    ;;
esac
