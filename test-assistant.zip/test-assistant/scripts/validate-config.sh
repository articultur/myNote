#!/usr/bin/env bash
set -euo pipefail

CONFIG_PATH="${1:-.test-assistant/config.json}"

if [[ ! -f "${CONFIG_PATH}" ]]; then
  echo "ERROR: config file not found: ${CONFIG_PATH}" >&2
  exit 1
fi

python3 - "$CONFIG_PATH" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])

try:
    data = json.loads(path.read_text(encoding="utf-8"))
except Exception as exc:
    print(f"ERROR: invalid json in {path}: {exc}", file=sys.stderr)
    sys.exit(1)

errors = []
warnings = []

source_fields = [
    "knowledgeBases",
    "repositories",
    "yuqueNamespaces",
    "testKnowledgeBases",
    "testReportYuqueUrls",
    "testCodeRepos",
]

for field in source_fields:
    if field in data and not isinstance(data[field], list):
        errors.append(f"{field} must be an array")

has_any_source = any(
    isinstance(data.get(field), list) and len(data[field]) > 0
    for field in source_fields
)
if not has_any_source:
    errors.append(
        "at least one source field must be configured: "
        "knowledgeBases/repositories/yuqueNamespaces/"
        "testKnowledgeBases/testReportYuqueUrls/testCodeRepos"
    )

mcps = data.get("mcps", [])
if mcps is None:
    mcps = []
if not isinstance(mcps, list):
    errors.append("mcps must be an array")
else:
    seen = set()
    for i, mcp in enumerate(mcps):
        if not isinstance(mcp, dict):
            errors.append(f"mcps[{i}] must be an object")
            continue
        name = mcp.get("name")
        if not isinstance(name, str) or not name.strip():
            errors.append(f"mcps[{i}].name must be a non-empty string")
        elif name in seen:
            errors.append(f"duplicate MCP name: {name}")
        else:
            seen.add(name)

        required = mcp.get("required", False)
        if not isinstance(required, bool):
            errors.append(f"mcps[{i}].required must be boolean")

        cmd = mcp.get("installCommand")
        if cmd is not None and not isinstance(cmd, str):
            errors.append(f"mcps[{i}].installCommand must be string when set")
        if required and not isinstance(cmd, str):
            warnings.append(f"mcps[{i}] is required but installCommand is not provided")

version = data.get("version")
if version is not None and not isinstance(version, str):
    errors.append("version must be string when set")

# All known placeholder values per field (collected from config.example.json).
# A field is considered unconfigured when every element in its array is one
# of these placeholder strings, regardless of how many different placeholders
# are present.
array_placeholders = {
    "knowledgeBases": {"kb-xxxxx", "kb-yyyyy"},
    "repositories": {
        "https://code.alipay.com/xxx/yyy.git",
        "https://code.alipay.com/aaa/bbb.git",
    },
    "yuqueNamespaces": {"tangxinyu.txy/1111", "tangxinyu.txy/2222"},
    "testKnowledgeBases": {"kb-xxxxx"},
    "testReportYuqueUrls": {"https://yuque.antfin.com/<team>/<test-report-space>"},
    "testCodeRepos": {"https://code.alipay.com/<group>/<test-repo>.git"},
}
for field, placeholders in array_placeholders.items():
    val = data.get(field, [])
    if not isinstance(val, list):
        errors.append(f"{field} must be an array")
    elif not val or all(v in placeholders for v in val):
        warnings.append(f"{field} is not configured — set it in config.json for full functionality")

if errors:
    print("Config validation failed:", file=sys.stderr)
    for item in errors:
        print(f"  - {item}", file=sys.stderr)
    sys.exit(1)

print("Config validation passed.")
if warnings:
    print("Warnings:")
    for item in warnings:
        print(f"  - {item}")
PY
