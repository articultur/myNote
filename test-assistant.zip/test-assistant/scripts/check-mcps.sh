#!/usr/bin/env bash
set -euo pipefail

CONFIG_PATH="${1:-.test-assistant/config.json}"

if [[ ! -f "${CONFIG_PATH}" ]]; then
  echo "ERROR: config file not found: ${CONFIG_PATH}" >&2
  exit 1
fi

if ! command -v claude >/dev/null 2>&1; then
  echo "ERROR: claude CLI not found in PATH" >&2
  exit 2
fi

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "${TMP_DIR}"' EXIT

MCP_LIST_RAW="${TMP_DIR}/mcp-list.txt"
claude mcp list > "${MCP_LIST_RAW}"

python3 - "$CONFIG_PATH" "$MCP_LIST_RAW" <<'PY'
import json
import pathlib
import re
import sys

config_path = pathlib.Path(sys.argv[1])
list_path = pathlib.Path(sys.argv[2])

config = json.loads(config_path.read_text(encoding="utf-8"))
mcps = config.get("mcps") or []
if not isinstance(mcps, list):
    print("ERROR: mcps must be an array", file=sys.stderr)
    sys.exit(1)

raw = list_path.read_text(encoding="utf-8", errors="ignore")
installed = set()
for line in raw.splitlines():
    line = line.strip()
    if not line:
        continue
    # Common output patterns:
    # - name
    # - name (SSE)
    # - * name
    # - name: <url> - ✓/✗ ...   (claude mcp list actual format)
    m = re.match(r"^[*\-]?\s*([a-zA-Z0-9_.-]+):?(?:\s|$)", line)
    if m:
        token = m.group(1)
        # skip obvious table headers
        if token.lower() in {"name", "status", "type"}:
            continue
        installed.add(token)

if not mcps:
    print("No MCPs configured. Skip check.")
    sys.exit(0)

missing_required = []
print("MCP check result:")
for mcp in mcps:
    if not isinstance(mcp, dict):
        print("  - INVALID ENTRY (non-object)")
        continue
    name = mcp.get("name")
    required = bool(mcp.get("required", False))
    install = mcp.get("installCommand")
    if not isinstance(name, str) or not name:
        print("  - INVALID ENTRY (missing name)")
        continue

    ok = name in installed
    status = "OK" if ok else "MISSING"
    level = "required" if required else "optional"
    print(f"  - {name}: {status} ({level})")

    if required and not ok:
        missing_required.append((name, install))

if missing_required:
    print("\nRequired MCPs missing:")
    for name, install in missing_required:
        print(f"  - {name}")
        if isinstance(install, str) and install.strip():
            print(f"    install: {install}")
        else:
            print("    install: (not provided in config)")
    sys.exit(3)

print("\nAll required MCPs are installed.")
PY
