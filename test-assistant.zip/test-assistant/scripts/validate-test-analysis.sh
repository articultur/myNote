#!/usr/bin/env bash
# 用法: ./validate-test-analysis.sh <REQ-ID>
# 检查测试分析文档的完整性：
# 1. 是否包含所有必需章节
# 2. 每个测试点是否有前置条件、输入、输出
# 3. 是否有上下文追溯标记
# 4. 是否有待确认项标注
# 退出码: 0 = 通过, 1 = 失败

set -euo pipefail

REQ_ID="${1:-}"
if [[ -z "$REQ_ID" ]]; then
  echo "ERROR: REQ-ID is required" >&2
  exit 1
fi

ANALYSIS_DOC="docs/requirements/${REQ_ID}/test-analysis.md"
if [[ ! -f "$ANALYSIS_DOC" ]]; then
  echo "ERROR: Analysis doc not found: $ANALYSIS_DOC" >&2
  exit 1
fi

python3 - "$ANALYSIS_DOC" <<'PY'
import sys
import re
from pathlib import Path

doc_path = Path(sys.argv[1])
content = doc_path.read_text(encoding="utf-8") if doc_path.exists() else ""

errors = []
warnings = []

# 1. 检查必需章节
required_sections = [
    "变更范围",
    "风险点",
    "测试建议",
    "测试步骤"
]
for section in required_sections:
    if section not in content:
        errors.append(f"缺少必需章节: {section}")

# 2. 检查每个测试点是否有前置条件、输入、输出
# 查找所有测试点（以 "### " 或 "#### " 开头的测试相关标题）
test_pattern = r'(?:^|\n)(?:###|####)\s*(.*?(?:测试|验证|检查|校验|场景|case))'
test_matches = list(re.finditer(test_pattern, content, re.MULTILINE))

for match in test_matches:
    test_name = match.group(1).strip()
    # 提取测试点后续内容（约 200 字符）
    start = match.end()
    end = min(start + 500, len(content))
    test_section = content[start:end]

    # 检查是否包含前置条件、输入、输出
    has_prerequisite = any(kw in test_section for kw in ["前置", "前提", "条件", "准备"])
    has_input = any(kw in test_section for kw in ["输入", "入参", "参数", "data", "input"])
    has_output = any(kw in test_section for kw in ["预期", "输出", "result", "output", "assert"])

    if not (has_prerequisite and has_input and has_output):
        warnings.append(f"测试点「{test_name}」可能缺少前置条件/输入/输出说明")

# 3. 检查是否有上下文追溯标记
# 正常应有来源标注，如 [来源: xxx.md] 或 (来源: 文件位置)
has_trace_markers = bool(re.search(r'\[来源[:：]|来源[:：]\s*[\[`]|来自\s*[\[`/]', content))
if not has_trace_markers and len(test_matches) > 0:
    warnings.append("文档中未发现上下文追溯标记，建议为每个测试点标注来源")

# 4. 检查是否有待确认项标注
has_pending = "待确认" in content or "待补充" in content or "[待确认]" in content
if not has_pending:
    # 如果有待确认项，应该有标注
    pending_items = re.findall(r'(?:待确认|待补充)[：:]\s*(.+?)(?:\n|$)', content)
    if pending_items:
        warnings.append(f"存在 {len(pending_items)} 项待确认内容，请确保有对应补充计划")

# 输出结果
if errors:
    print("ERRORS:")
    for e in errors:
        print(f"  - {e}")
    print()

if warnings:
    print("WARNINGS:")
    for w in warnings:
        print(f"  - {w}")
    print()

if errors:
    print(f"Validation failed: {len(errors)} error(s), {len(warnings)} warning(s)")
    sys.exit(1)
elif warnings:
    print(f"Validation passed with {len(warnings)} warning(s)")
    sys.exit(0)
else:
    print("Validation passed")
    sys.exit(0)
PY
