---
name: revealjs-presentation
description: >
  Generate professional reveal.js HTML presentations when users ask to create presentations,
  make slides, build PPT decks, or produce HTML presentation content. Trigger phrases include:
  "帮我做一个关于 X 的演示文稿", "生成 HTML slides", "创建 PPT", "make a presentation about X",
  "create slides from this outline", "build a reveal.js showcase", "prepare a talk on X",
  or providing an outline for slide generation. Applicable for technical talks, teaching
  materials, product demos, and conference presentations.
metadata:
  version: 14.4
  author: Claude
  created: 2026-03-28
  updated: 2026-04-01
  changelog: |
    - v14.4: Phase 6 改为全自动：自动浏览器+结构化检测+动画末帧验证+自动清理
    - v14.3: 优化 SKILL.md：description 缩短，Pipeline ASCII art 改为表格
    - v14.2: Phase 6 改为全自动模式，去掉人工截图检查
    - v14.1: 增加垂直流程图溢出预防（≤7步）
    - v14.0: Pipeline 强制执行机制：BLOCKER 表 + description 约束
  tags: [presentation, html, reveal.js, slides, ppt, prompt-template]
  category: tools
  icon: data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect x='10' y='20' width='80' height='60' rx='5' fill='%233B82F6'/><rect x='15' y='25' width='70' height='50' rx='3' fill='%23fff'/><line x1='25' y1='40' x2='75' y2='40' stroke='%233B82F6' stroke-width='3'/><line x1='25' y1='50' x2='60' y2='50' stroke='%2394A3B8' stroke-width='2'/><line x1='25' y1='60' x2='50' y2='60' stroke='%2394A3B8' stroke-width='2'/></svg>
compatibility: "tools: Read, Edit, Write, Bash; dependencies: none"
license: Based on impeccable design framework. See references for anti-patterns.
---

# Reveal.js Presentation Skill

Generate professional reveal.js HTML presentations with distinctive design, following the impeccable design framework workflow.

---

## 设计流程 (Design Pipeline)

**7 阶段顺序执行**：

| 阶段 | 名称 | 类型 | 说明 |
|:----:|------|:----:|------|
| P0 | 设计上下文 | ● 强制 | 确认设计风格、色彩、字体方向 |
| P1 | 需求+模板 | ● 强制 | 确认场景、时长、听众、选择模板 |
| P2 | 输出方案 | ◐ 条件 | 确认内容结构、视觉方向 |
| P3 | 设计评审 | ● 强制 | `/critique` 评审 + 优化方向 |
| P4 | 生成初稿 | ● 强制 | 生成 HTML 文件 |
| P5 | 优化迭代 | ● 强制 | 根据 slide 数量执行对应 skills |
| P6 | 最终检查 | ◐ 条件 | 溢出检测 + CSS 修复 + 复检（可跳过） |

**执行规则**：
- **● 标记**：必须完成，不可跳过
- **◐ 标记**：上下文已存在时可跳过
- **Gate 是 BLOCKER**：每阶段必须向用户展示输出，获得确认后才能进入下一阶段

**为什么要按顺序执行**：跳过 Phase 2/3/5 直接输出会导致内容结构不合理、视觉质量差、溢出问题多。先确认方案再生成，可以避免返工。

**Gate 速查表：**

| Gate | 阶段 | 必须向用户确认的内容 |
|:----:|------|---------------------|
| 0 | 设计上下文 | 设计风格/色彩/字体方向 |
| 1 | 需求+模板 | 场景、时长、听众、模板选择 |
| 2 | 方案 | 内容结构、视觉方向（跳过条件：用户提供完整需求）|
| 3 | 设计评审 | `/critique` 报告 + 优化方向确认 |
| 4 | 生成初稿 | HTML 文件路径 |
| 5 | 优化迭代 | 执行的 skills 列表和结果 |
| 6 | 最终检查 | Phase 6 检查报告 + 用户交付确认 |

---

### Phase 0: 设计上下文 (Design Context) — **GATE 0 ●**

```
/teach-impeccable
```

**目的**：确认项目设计上下文，确保生成内容符合品牌和用户期望。

**交付物**：设计上下文文档（`.impeccable.md` 或 CLAUDE.md 中的上下文）

**Gate 检查**：
- [ ] 已运行 `/teach-impeccable`
- [ ] 设计方向已确认（风格/色彩/字体）
- [ ] 反模式已记录

**跳过条件**：`.impeccable.md` 或 CLAUDE.md 已存在有效上下文。

---

### Phase 1: 需求确认 + 模板选择 (Requirements) — **GATE 1 ●**

**第一步：确认场景和时长**

1. **场景**：技术演讲 / 产品发布 / 教学课件 / 内部汇报？
2. **时长**：预计多少页？多少分钟？
3. **听众**：技术背景？管理层？客户？

**第二步：展示模板选项**

用户说"要生成 PPT"时，**立即展示模板选项**，不要直接选：

```
## 请选择模板风格

| 序号 | 模板 | 风格描述 | 适用场景 |
|:----:|------|----------|----------|
| 1 | `template-01-editorial-serif` | 社论衬线风格，Newsreader + Source Sans，优雅经典 | 学术演讲、正式汇报 |
| 2 | `template-02-dark-tech` | 深色技术风，OKLCH 亮度深度，沉浸感强 | 科技产品发布、技术演示 |
| 3 | `template-03-minimal-spatial` | 空间网格风格，4pt 间距系统，结构清晰 | 教学课件、架构图解 |
| 4 | `template-04-vibrant-gradient` | 活力渐变风格，色彩丰富，视觉冲击 | 营销演示、创意展示 |
| 5 | `template-05-nature-fresh` | 自然清新风格，柔和色调，清爽舒适 | 内部分享、日常汇报 |

请回复序号（1-5）或描述您想要的风格。
```

**交付物**：需求确认清单 + 用户选择的模板序号

**Gate 检查**：
- [ ] 场景已明确
- [ ] 模板已选定（用户回复序号）
- [ ] 听众已确认

**跳过条件**：用户提供完整需求且指定模板。

---

### Phase 2: 输出方案 (Proposal) — **GATE 2 ◐**

**基于需求，输出设计方案：**

```markdown
## 演示文稿设计方案

### 1. 选定模板
[模板序号] + [模板名称] + [风格描述]

### 2. 内容结构
- Slide 1: 标题页
- Slide 2-N: 内容页
- 最后: 总结/致谢

**内容拆分检查**：当一页内容过多需要拆分为多页时（如 9 项列表拆成 4+5），必须：
1. 列出所有原始项的完整清单
2. 每复制一项到新位置后做标记
3. 拆分后核对总数是否一致

### 3. 视觉方向
- 色彩方案：主色/强调色/中性色
- 字体配对：[标题字体] + [正文字体]
- 布局特点：左对齐/大量留白/视觉层次

### 4. 动效策略
- 入场动画：stagger / fade / slide
- 强调动画：[具体应用场景]
- Reduced motion 支持：✓

### 5. 需要用户确认的点
- [具体问题]
```

**交付物**：设计方案文档（内容结构、视觉方向）

**Gate 检查**：
- [ ] 方案已输出
- [ ] 用户已确认内容结构
- [ ] 无明显 AI-slop 风险

**跳过条件**：用户提供参考设计或明确需求，可直接进入 Phase 4。

---

### Phase 3: 设计评审 (Design Critique) — **GATE 3 ●**

**执行方式**：由 AI 自动执行 `/critique <file-path>` 命令（Claude Code 内部调用 impeccable:critique skill）

**评审维度：**
- AI-slop 检测（anti-patterns）
- 视觉层次结构
- 信息架构 / 认知负荷
- 情感体验
- 可发现性 / 可供性
- 排版与色彩
- 状态与边缘情况

**交付物**：评审报告 + 优化优先级列表

**Gate 检查**：
- [ ] 已运行 `/critique`
- [ ] 主要问题已识别（≤ 3 项优先修复）
- [ ] 用户已确认优化方向

---

### Phase 4: 生成初稿 (Draft) — **GATE 4 ●**

1. **加载模板**：根据 Phase 1 用户选择的模板，加载对应的 `template-XX-*.html` 文件
2. **填充内容**：将用户提纲映射到模板结构，每页一个核心观点
3. **生成 HTML**：完整的可运行文件

**交付物**：完整的 `template-*.html` 文件

**Gate 检查**：
- [ ] HTML 文件已生成
- [ ] 本地浏览器测试无错误
- [ ] Slide 数量与规划一致

---

### Phase 5: 优化迭代 (Optimization) — **GATE 5 ●**

**根据演示复杂度选择优化层级：**

```
< 5 slides  ────▶  Simple Tier (5 skills)
5-15 slides  ──▶  Standard Tier (7 skills)
> 15 slides  ──▶  Full Tier (12 skills)
```

#### Simple Tier (< 5 slides)
**快速优化，仅核心 skills**：

| # | 命令 | 用途 |
|---|-----|------|
| 1 | `/arrange` | 布局节奏 |
| 2 | `/typeset` | 字体排版 |
| 3 | `/colorize` | 色彩系统 |
| 4 | `/clarify` | 文案清晰 |
| 5 | `/distill` | 去除冗余 |

#### Standard Tier (5-15 slides)
**标准优化，核心 + 动效 + 润色**：

| # | 命令 | 用途 |
|---|-----|------|
| 1-5 | (同 Simple) | 核心优化 |
| 6 | `/animate` | 添加动效 |
| 7 | `/polish` | 最终润色 |

#### Full Tier (> 15 slides 或 正式演讲)
**完整优化，全部 12 skills**：

| # | 命令 | 用途 |
|---|-----|------|
| 1 | `/arrange` | 布局节奏 |
| 2 | `/typeset` | 字体排版 |
| 3 | `/colorize` | 色彩战略 |
| 4 | `/clarify` | 改进文案 |
| 5 | `/distill` | 提炼精华 |
| 6 | `/animate` | 添加动效 |
| 7 | `/delight` | 添加惊喜 |
| 8 | `/bolder` | 增强表现力（如需要） |
| 9 | `/quieter` | 减弱嘈杂（如需要） |
| 10 | `/optimize` | 性能优化 |
| 11 | `/harden` | 增强健壮性 |
| 12 | `/polish` | 最终润色 |

**执行顺序**：#1-5 → #6-7 → #8-9（如需要）→ #10-12

**执行方式**：
- **连续执行**：不要在每个 skill 后停下来等确认，一次性运行完该层级的全部 skills
- 如果某个 skill 不适用（如 `#8-9 如需要`），跳过即可
- 所有 skills 执行完后，再输出优化记录

**交付物**：优化记录（含执行的 skills 列表和结果）

**Gate 检查**：
- [ ] 已根据 slide 数量选择对应层级
- [ ] 该层级全部 skills 已执行
- [ ] 优化记录已输出

---

#### Phase 6 入口询问

Phase 5 完成后，**使用 `AskUserQuestion` 工具弹出选择**（不要输出文本让用户手动回复）：

```
questions: [{
  "question": "是否需要进行最终检查？",
  "header": "Phase 6",
  "options": [
    {"label": "是", "description": "自动扫描溢出 → 自动修复 → 结构化报告 → 按需截图验证"},
    {"label": "否", "description": "跳过检查，直接交付"}
  ],
  "multiSelect": false
}]
```

- 用户选择「**否**」→ 跳过 Phase 6，直接交付
- 用户选择「**是**」→ 进入 Phase 6 Step 1

---

### Phase 6: 最终检查 (Final Check) — **GATE 6 ◐**

**自动模式：自动扫描 → 自动修复 CSS → 自动复检 → 按需截图验证**

---

#### Step 1: 自动启动 HTTP 服务器

由于浏览器安全策略，`file://` 协议无法直接访问。自动启动本地服务器：

```bash
cd <HTML文件所在目录> && python3 -m http.server 8765 &
```

**自动清理**：Phase 6 完成后自动 kill 进程。

---

#### Step 2: Playwright Headless 扫描

**自动启动 headless 浏览器**，执行结构化溢出检测：

```javascript
// Reveal.js 缩放模式下正确检测真实溢出
() => {
  const scale = window.Reveal.getScale();
  const vp = { width: window.innerWidth, height: window.innerHeight };
  const realOverflows = [];

  document.querySelectorAll('section').forEach((sec, si) => {
    // 只检查 scrollWidth/clientWidth（不受 CSS transform 影响）
    if (sec.scrollWidth > sec.clientWidth || sec.scrollHeight > sec.clientHeight) {
      realOverflows.push({
        slide: si,
        scroll: { w: sec.scrollWidth, h: sec.scrollHeight },
        client: { w: sec.clientWidth, h: sec.clientHeight }
      });
    }
  });

  return { scale, vp, realOverflows, count: realOverflows.length };
}
```

**Reveal.js URL 动画分页格式**：
- `/#/slideIndex` → 第 N 页
- `/#/slideIndex/0/fragmentIndex` → 第 N 页的第 0 个垂直布局的第 M 个动画分页

---

#### Step 3: 结构化检测结果

| 情况 | 输出 | 后续动作 |
|------|------|---------|
| `count = 0` | ✅ 无溢出 | 跳过 Step 4-6，直接进入 Step 7 |
| `count > 0` | ⚠️ 检测到 N 个问题 | 进入 Step 4 截图验证 |

---

#### Step 4: 按需截图验证（有问题时）

**触发条件**：检测到 `count > 0`

**验证策略**：
1. 导航到**动画末帧**（`/#/slideIndex/0/maxFragment`）而非首页
2. 截图该页面
3. 模型/用户视觉确认

```javascript
// 跳转到动画末帧并截图
() => {
  const slideIndex = <有问题页面的索引>;
  const fragments = window.Reveal.getSlideFragments(slideIndex, 0);
  const maxFragment = fragments ? Math.max(...fragments.map(f => f.index)) : 0;
  window.Reveal.slide(slideIndex, 0, maxFragment);
  return `navigated to /#/${slideIndex}/0/${maxFragment}`;
}
```

**截图文件**：`/<slide-index>-verify.png`

---

#### Step 5: 自动修复 CSS

运行 `scripts/auto-fix-css.js` 自动修复：

| 代码 | 问题 | 自动修复 |
|-----|------|---------|
| A1 | Flex 子项溢出 | `min-width: 0` |
| A2 | Grid `1fr` 溢出 | `minmax(0, 1fr)` |
| A3 | 长文本溢出 | `overflow-wrap: anywhere` |

---

#### Step 6: 自动复检

重新运行 Step 2，确认 `count = 0`。

- `count = 0` → 检查通过 ✅
- `count > 0` → 报告未解决问题，人工处理

---

#### Step 7: 自动清理

**完成后自动执行**：
1. 关闭 Playwright 浏览器
2. Kill HTTP 服务器进程
3. 删除所有截图和临时文件

---

#### 最终报告格式

```markdown
## Phase 6 最终检查报告

### 自动扫描结果
- 初始溢出报告：N（误报）
- 原因：Reveal.js CSS transform 缩放
- 真实溢出检测：0 ✅

### 视觉验证（如有）
- 截图文件：[列表]
- 验证结果：通过 ✅

### 检查清单
- [ ] 颜色使用 OKLCH（非 #hex）
- [ ] 强调色 chroma ≤ 15%
- [ ] Reveal.js CDN 4.6.x 有效
- [ ] cubic-bezier 缓动 (ease-out-expo)
- [ ] prefers-reduced-motion 支持

### 交付物
[文件路径] - [页数] 页
```

---

#### 检测策略总结

| 层级 | 策略 | 说明 |
|------|------|------|
| **首选** | 结构化检测 | `scrollWidth > clientWidth`，机器可读 |
| **兜底** | 截图验证 | 仅在 `count > 0` 时触发 |
| **降级** | 无图像能力 | 纯结构化结果作为最终结论 |

---

#### 基础检查清单（快速目视，无需截图）

**功能检查：**
- [ ] Reveal.js CDN 有效
- [ ] `prefers-reduced-motion` 支持
- [ ] Speaker Notes 存在

**内容完整性检查：**
- [ ] 拆分后的内容总数与原始清单一致（如 9 项拆成 4+5）

**注意**：颜色/字体/布局等视觉检查已在 Phase 3-5 的优化流程中覆盖。

**Gate 检查：**
- [ ] 用户已选择进入 Phase 6（或跳过）
- [ ] Step 2 扫描无真实溢出（或 Step 5 已自动修复）
- [ ] 截图验证（如有）已通过
- [ ] 临时文件已清理
- [ ] 用户确认交付

---

## 附录A: 溢出预防 (Overflow Prevention)

Phase 6 的半自动检查已涵盖检测和修复流程。

**核心原则：**
- **宁可保守设计**（内容偏少），事后微调放大
- **不要设计太满**，否则溢出后无解
- 每次修改后**立即验证**，不要批量修改后才发现问题

**预防检查清单（设计时执行）：**
- [ ] 3列卡片：每卡 padding ≤ 1em，gap ≤ 0.8em
- [ ] 6列网格：每卡 padding ≤ 0.7em，gap ≤ 0.6em
- [ ] 列表：每项 margin ≤ 0.3em，最多 4 项
- [ ] h2 margin-bottom ≤ 0.5em
- [ ] clamp() 最大值：h1 ≤ 2.5em，h2 ≤ 1.8em，正文 ≤ 0.95em
- [ ] **垂直流程图：最多 7 步（含首尾），超过则拆页或改横向**
- [ ] **混合布局（标题+流程图+卡片）：先验证总高度不超限**

详细代码示例见 `references/layout-patterns.md`。

---

## 模板示例 (Template Examples)

完整模板列表在 Phase 1 展示。模板文件位于 `examples/` 目录：

- `template-01-editorial-serif.html` — 社论衬线
- `template-02-dark-tech.html` — 深色技术
- `template-03-minimal-spatial.html` — 空间网格
- `template-04-vibrant-gradient.html` — 活力渐变
- `template-05-nature-fresh.html` — 自然清新

---

## 详细参考 (References)

| 文件 | 内容 |
|------|------|
| `references/design-principles.md` | 颜色方案、字体选择，反模式（impeccable） |
| `references/layout-patterns.md` | 布局代码示例、溢出处理 |
| `references/motion-delight.md` | 动画时序、缓动曲线、stagger 模式 |
| `references/technical-specs.md` | CDN 依赖、配置参数、CSS 约束 |

---

## 输出要求 (Output Requirements)

交付完整可运行的单个 HTML 文件，包含：

1. Reveal.js 4.6.x CDN 链接
2. Reveal.initialize() 初始化配置
3. 自定义 CSS 样式（含 CSS 变量）
4. 完整的 `<section>` 幻灯片结构
5. Speaker Notes（演讲者备注）

---

## 快捷键 (Keyboard Shortcuts)

| 快捷键 | 功能 |
|--------|------|
| `→` `Space` | 下一页 |
| `←` | 上一页 |
| `f` | 全屏 |
| `s` | 演讲者视图 |
| `Esc` | 退出 |

---

## PDF 导出 (PDF Export)

1. 打开 HTML 文件
2. `Cmd + P` 打印
3. 选择"另存为 PDF"
4. Chrome 效果最佳

---

## 外部资源 (External Resources)

- [impeccable framework](https://github.com/pbakaus/impeccable)
- [reveal.js 官网](https://revealjs.com)
