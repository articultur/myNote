# Reveal.js Presentation Generation Skill

> Professional reveal.js HTML presentation generation prompt template, powered by impeccable design principles

---

## Overview

This is an **AI prompt template** for generating professional reveal.js presentations with distinctive, non-generic design.

---

## Directory Structure

```
revealjs-presentation/
├── SKILL.md                           # Core prompt template
├── references/
│   ├── design-principles.md           # Color schemes, typography, anti-patterns
│   ├── layout-patterns.md             # Layout patterns, overflow case studies
│   ├── motion-delight.md              # Animation timing, easing, stagger, delight moments
│   └── technical-specs.md             # CDN dependencies, configuration, CSS
├── examples/
│   └── sample-presentation.html       # Complete runnable template
└── README.md                          # This file
```

---

## Design Philosophy

This skill integrates [impeccable](https://github.com/pbakaus/impeccable) design framework principles:

### Anti-Patterns to Avoid

| ❌ Avoid | ✅ Instead |
|---------|----------|
| Inter/Roboto/Arial fonts | Noto Sans SC, Source Serif 4 |
| Pure black (#000) or white (#fff) | Tint toward brand hue |
| Gray text on colored backgrounds | Use background's darker shade |
| Purple-to-blue gradients | Single accent color + neutral |
| Cards nested in cards | Flatten hierarchy |
| Everything centered | Left-align with asymmetric layouts |

### The AI Slop Test

A distinctive presentation should make someone ask "how was this made?" not "which AI made this?"

---

## Usage

### Method 1: Send to AI

1. Open `SKILL.md`
2. Copy the entire content
3. Paste as AI's **system prompt**
4. Describe the topic and outline
5. AI generates a complete HTML presentation

### Method 2: Use as Reference

Read `SKILL.md` directly to understand reveal.js best practices and design specifications.

---

## Example Prompt

```
Please act as a professional presentation designer...

[Paste SKILL.md content as system prompt]

---

Now please help me design a presentation about "Memory System Architecture",
containing:
1. Architecture Overview
2. Core Components
3. Data Flow
4. Design Principles
```

---

## Resources

| File | Description |
|------|-------------|
| `SKILL.md` | Core prompt with role definition, design principles, layout patterns |
| `references/design-principles.md` | Detailed color schemes, typography, anti-patterns (impeccable) |
| `references/layout-patterns.md` | Layout code examples, fragment animations, overflow cases |
| `references/motion-delight.md` | Animation timing (100/300/500 rule), easing curves, stagger patterns, personality copy, delight moments |
| `references/technical-specs.md` | CDN, Reveal.js configuration, CSS constraints |
| `examples/sample-presentation.html` | Complete runnable presentation template with hover micro-interactions, stagger fragments, reduced motion, and easter egg |

---

## Keyboard Shortcuts (reveal.js)

| Shortcut | Function |
|----------|----------|
| `→` `Space` | Next slide |
| `←` | Previous slide |
| `f` | Fullscreen |
| `s` | Speaker view |
| `Esc` | Exit |

---

## PDF Export

1. Open the generated HTML file
2. `Cmd + P` to print
3. Select "Save as PDF"
4. Chrome provides the best results

---

## Related Resources

- [impeccable framework](https://github.com/pbakaus/impeccable)
- [impeccable.style](https://impeccable.style)
- Official Website: https://revealjs.com
- GitHub: https://github.com/hakimel/reveal.js
- Chinese: https://reveal.nodejs.cn
